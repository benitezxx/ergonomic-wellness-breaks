const API_URL = "http://127.0.0.1:8000";

async function request(path, options = {}) {
  const config = {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    ...options
  };

  const response = await fetch(`${API_URL}${path}`, config);
  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await response.json()
    : { message: await response.text() };

  if (!response.ok) {
    throw new Error(data.detail || data.message || "Error de comunicación con la API.");
  }

  return data;
}

window.WellnessAPI = {
  apiUrl: API_URL,
  registerFace(payload) {
    return request("/auth/register-face", {
      method: "POST",
      body: JSON.stringify(payload)
    });
  },
  loginFace(payload) {
    return request("/auth/login-face", {
      method: "POST",
      body: JSON.stringify(payload)
    });
  },
  getUser(userId) {
    return request(`/users/${userId}`);
  },
  getUsers() {
    return request("/users");
  },
  deleteUser(userId) {
    return request(`/users/${userId}`, {
      method: "DELETE"
    });
  },
  getUserHistory(userId, month) {
    const suffix = month ? `?month=${encodeURIComponent(month)}` : "";
    return request(`/users/${userId}/history${suffix}`);
  },
  getLeaderboard(limit = 10) {
    return request(`/leaderboard?limit=${limit}`);
  },
  getAdminDashboard() {
    return request("/admin/dashboard");
  },
  getAdminAnalytics(month, userId) {
    const params = new URLSearchParams();
    if (month) params.set("month", month);
    if (userId) params.set("user_id", String(userId));
    const suffix = params.toString() ? `?${params.toString()}` : "";
    return request(`/admin/analytics${suffix}`);
  },
  getExercises(includeInactive = false) {
    const suffix = includeInactive ? "?include_inactive=true" : "";
    return request(`/exercises${suffix}`);
  },
  createExercise(payload) {
    return request("/exercises", {
      method: "POST",
      body: JSON.stringify(payload)
    });
  },
  updateExercise(exerciseId, payload) {
    return request(`/exercises/${exerciseId}`, {
      method: "PUT",
      body: JSON.stringify(payload)
    });
  },
  deleteExercise(exerciseId) {
    return request(`/exercises/${exerciseId}`, {
      method: "DELETE"
    });
  },
  getRewards(includeInactive = false) {
    const suffix = includeInactive ? "?include_inactive=true" : "";
    return request(`/rewards${suffix}`);
  },
  createReward(payload) {
    return request("/rewards", {
      method: "POST",
      body: JSON.stringify(payload)
    });
  },
  updateReward(rewardId, payload) {
    return request(`/rewards/${rewardId}`, {
      method: "PUT",
      body: JSON.stringify(payload)
    });
  },
  redeemReward(userId, rewardId) {
    return request("/rewards/redeem", {
      method: "POST",
      body: JSON.stringify({
        user_id: userId,
        reward_id: rewardId
      })
    });
  },
  startSession(userId, exerciseId) {
    return request("/sessions/start", {
      method: "POST",
      body: JSON.stringify({
        user_id: userId,
        exercise_id: exerciseId
      })
    });
  },
  processFrame(sessionId, landmarks) {
    return request(`/sessions/${sessionId}/frame`, {
      method: "POST",
      body: JSON.stringify({ landmarks })
    });
  },
  completeSession(sessionId, durationSeconds) {
    return request(`/sessions/${sessionId}/complete`, {
      method: "POST",
      body: JSON.stringify({
        duracion_segundos: durationSeconds
      })
    });
  }
};
