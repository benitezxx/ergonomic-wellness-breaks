import {
  cargarModelosFaciales,
  registrarUsuario,
  loginUsuario
} from "./face_ai.js?v=20260503-security-admin-1";

const SESSION_KEYS = ["user", "role", "userId", "currentUser"];

const video = document.getElementById("video");
const statusMessage = document.getElementById("statusMessage");
const loginViewport = document.getElementById("loginViewport");

let isLogging = false;
let isReady = false;
let isRegistering = false;

SESSION_KEYS.forEach(key => localStorage.removeItem(key));

function fitLoginViewport() {
  if (!loginViewport) return;

  loginViewport.style.transform = "translateX(-50%) scale(1)";
  loginViewport.style.top = "0px";

  const naturalWidth = loginViewport.offsetWidth;
  const naturalHeight = loginViewport.offsetHeight;
  const padding = 16;
  const scale = Math.min(
    (window.innerWidth - padding * 2) / naturalWidth,
    (window.innerHeight - padding * 2) / naturalHeight,
    1
  );
  const topOffset = Math.max(padding, Math.floor((window.innerHeight - naturalHeight * scale) / 2));

  loginViewport.style.top = `${topOffset}px`;
  loginViewport.style.transform = `translateX(-50%) scale(${scale})`;
}

function setStatus(message, state = "info") {
  if (!statusMessage) return;
  statusMessage.textContent = message;
  statusMessage.dataset.state = state;
  fitLoginViewport();
}

async function startCamera() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: false
    });

    video.srcObject = stream;

    await new Promise(resolve => {
      video.onloadedmetadata = () => {
        video.play();
        resolve();
      };
    });

    setStatus("Camara encendida. Buscando rostro...", "success");
  } catch (error) {
    console.error("Error camara:", error);
    setStatus("No se pudo acceder a la camara.", "error");
    alert("No se pudo acceder a la camara");
  }
}

async function autoLogin() {
  if (isLogging || isRegistering || !isReady) return;

  isLogging = true;
  setStatus("Validando identidad con varias capturas...", "info");

  const result = await loginUsuario(video);

  if (result.validado) {
    setStatus(result.mensaje, "success");
    if (result.usuario.role === "admin") {
      window.location.href = "admin.html";
    } else {
      window.location.href = "index.html";
    }
    return;
  }

  setStatus(result.mensaje || "Esperando un rostro registrado...", "info");
  isLogging = false;
}

function startDetectionLoop() {
  window.setInterval(() => {
    autoLogin();
  }, 2500);
}

async function init() {
  setStatus("Encendiendo camara...", "info");
  await startCamera();

  setStatus("Cargando modelos faciales...", "info");
  await cargarModelosFaciales();

  isReady = true;
  setStatus("Sistema listo. Colocate frente a la camara o registrate.", "success");
  startDetectionLoop();
}

async function registerFace() {
  if (!isReady) {
    alert("Espera a que la camara cargue");
    return;
  }

  const name = document.getElementById("registerName").value.trim();
  const role = document.getElementById("role").value;

  if (!name) {
    alert("Ingresa el nombre");
    return;
  }

  isRegistering = true;
  setStatus("Registrando rostro con varias capturas...", "info");

  const result = await registrarUsuario(video, name, role);
  setStatus(result.mensaje, result.exito ? "success" : "error");
  alert(result.mensaje);

  isRegistering = false;

  if (result.exito) {
    if (role === "admin") {
      window.location.href = "admin.html";
    } else {
      window.location.href = "index.html";
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("registerBtn");
  if (btn) {
    btn.addEventListener("click", registerFace);
  }
  fitLoginViewport();
});

window.addEventListener("resize", fitLoginViewport);
window.addEventListener("orientationchange", fitLoginViewport);

init();
