from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, JSON, String, Text, func
from sqlalchemy.orm import relationship

from .database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(200), nullable=False, unique=True, index=True)
    role = Column(String(20), nullable=False, default="user")
    points_balance = Column(Integer, nullable=False, default=0)
    points_earned = Column(Integer, nullable=False, default=0)
    points_redeemed = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    sesiones = relationship(
        "SesionEntrenamiento",
        back_populates="usuario",
        cascade="all, delete-orphan",
    )
    rostros = relationship("UserFace", back_populates="usuario", cascade="all, delete-orphan")
    canjes = relationship("CanjeRecompensa", back_populates="usuario", cascade="all, delete-orphan")


class UserFace(Base):
    __tablename__ = "user_faces"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    image_path = Column(String(255), nullable=True)
    embedding = Column(JSON, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    usuario = relationship("User", back_populates="rostros")


class Ejercicio(Base):
    __tablename__ = "ejercicios"

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(50), nullable=False, unique=True, index=True)
    nombre = Column(String(100), nullable=False)
    descripcion = Column(Text, nullable=False)
    image_path = Column(String(255), nullable=True)
    color_hex = Column(String(20), nullable=False, default="#38bdf8")
    puntos_por_rep = Column(Integer, nullable=False, default=1)
    objetivo_reps = Column(Integer, nullable=False, default=10)
    duracion_segundos = Column(Integer, nullable=False, default=20)
    activo = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    sesiones = relationship(
        "SesionEntrenamiento",
        back_populates="ejercicio",
        cascade="all, delete-orphan",
    )


class SesionEntrenamiento(Base):
    __tablename__ = "sesiones_entrenamiento"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    ejercicio_id = Column(
        Integer,
        ForeignKey("ejercicios.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    started_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    ended_at = Column(DateTime(timezone=True), nullable=True)
    total_reps = Column(Integer, nullable=False, default=0)
    duracion_segundos = Column(Integer, nullable=False, default=0)
    points_earned = Column(Integer, nullable=False, default=0)
    status = Column(String(20), nullable=False, default="started")

    usuario = relationship("User", back_populates="sesiones")
    ejercicio = relationship("Ejercicio", back_populates="sesiones")


class Recompensa(Base):
    __tablename__ = "recompensas"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(120), nullable=False, unique=True)
    descripcion = Column(Text, nullable=False)
    costo_puntos = Column(Integer, nullable=False)
    stock = Column(Integer, nullable=True)
    activo = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    canjes = relationship("CanjeRecompensa", back_populates="recompensa")


class CanjeRecompensa(Base):
    __tablename__ = "canjes_recompensas"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    recompensa_id = Column(
        Integer,
        ForeignKey("recompensas.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    puntos_canjeados = Column(Integer, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    usuario = relationship("User", back_populates="canjes")
    recompensa = relationship("Recompensa", back_populates="canjes")
