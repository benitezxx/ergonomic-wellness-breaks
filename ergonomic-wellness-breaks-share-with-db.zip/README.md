# Ergonomic Wellness Breaks

Sistema de pausas activas con IA que permite:

- Registro e inicio de sesión biométrico mediante rostro.
- Validación de ejercicios en tiempo real con cámara.
- Acumulación de puntos por repeticiones correctas.
- Canje de recompensas.
- Impresión de ticket con puntos ganados y acumulados.
- Calendario de actividad del usuario con colores por ejercicio.
- Panel administrador para gestionar ejercicios, revisar usuarios y ver el top de rendimiento.

## Estructura del proyecto

- `Backend/`
  - `backend/`: API FastAPI + SQLAlchemy + base de datos persistente.
- `Frontend/`
  - `login.html`: registro facial e inicio de sesión por rostro.
  - `index.html`: menú de ejercicios, calendario, recompensas y ticket.
  - `admin.html`: panel administrador.
  - `css/` y `js/`: estilos y lógica del cliente.
- `Resources/`
  - `images/`: imágenes de ejercicios.
  - `audio/`: audios legacy.
  - `models/`: modelos faciales.
  - `docs/`: documentación y PDF.
  - `legacy_web/`: versión anterior preservada como referencia.

## Roles

- `admin`: puede modificar ejercicios, colores, metas sugeridas, consultar usuarios, puntos, sesiones y ranking.
- `user`: entra al menú de ejercicios, gana puntos, consulta su calendario y canjea recompensas.

## Base de datos

La app usa por defecto SQLite en `Backend/backend/wellness.db`.

Si quieres usar otra base, define la variable de entorno `DATABASE_URL` antes de levantar el backend.

Ejemplo:

```powershell
$env:DATABASE_URL="sqlite:///./Backend/backend/wellness.db"
```

## Instalación

```powershell
pip install -r requirements.txt
```

## Cómo ejecutar

1. Levanta la API:

```powershell
python -m uvicorn Backend.backend.main:app --reload
```

2. En otra terminal, sirve el frontend estático desde la raíz del proyecto:

```powershell
python -m http.server 5500
```

3. Abre en el navegador:

```text
http://127.0.0.1:5500/Frontend/login.html
```

## Compartir el proyecto en ZIP

Para compartir el proyecto sin romperlo, comprime solo estos elementos:

- `Backend/`
- `Frontend/`
- `Resources/`
- `README.md`
- `requirements.txt`
- `.env.example`

No incluyas:

- `gestos_env/` porque es un entorno virtual local y contiene rutas de tu maquina.
- `__pycache__/` porque solo son archivos temporales de Python.

`Backend/backend/wellness.db` si puede incluirse si quieres compartir la base actual con ejercicios, recompensas y usuarios ya cargados.
Si no quieres compartir datos previos o registros biometricos, elimina ese archivo antes de comprimir y el sistema volvera a crear la base al iniciar.

Prueba minima antes de compartir:

1. Descomprime el ZIP en otra carpeta.
2. Ejecuta `pip install -r requirements.txt`.
3. Levanta la API con `python -m uvicorn Backend.backend.main:app --reload`.
4. Sirve el frontend con `python -m http.server 5500`.
5. Abre `http://127.0.0.1:5500/Frontend/login.html`.

## Subida o despliegue

El frontend usa por defecto `http://127.0.0.1:8000` solo cuando detecta que corre en local.
Si lo subes a otro servidor, ahora tomara la misma URL de origen del navegador por defecto, o puedes definir manualmente la API con:

```html
<script>
window.WELLNESS_API_URL = "https://tu-backend.example.com";
</script>
```

Coloca ese bloque antes de cargar `js/api.js` si tu frontend y tu backend no van a vivir en la misma URL publica.

## Consideraciones para LumAcad

Si LumAcad solo te pide subir archivos del proyecto, comparte el ZIP limpio descrito arriba.

Si LumAcad te ofrece hosting o despliegue web, valida antes estos puntos:

1. Debe permitir ejecutar un backend Python/FastAPI de forma persistente.
2. El frontend debe servirse por `https://` o en `localhost`, porque el navegador requiere un contexto seguro para la camara.
3. El servidor debe poder alcanzar los scripts de MediaPipe cargados desde `cdn.jsdelivr.net`, o en su defecto tendras que alojarlos localmente.
4. Si el backend no queda en la misma URL publica del frontend, configura `window.WELLNESS_API_URL`.

## Flujo funcional

1. Registra un usuario con su rostro y elige si será `user` o `admin`.
2. El login detecta el rostro y redirige según el rol.
3. El usuario selecciona un ejercicio o abre el calendario mediante gestos.
4. Antes de comenzar puede usar una meta sugerida o modo libre.
5. La API valida repeticiones correctas por sesión.
6. El ejercicio termina manualmente con un botón gestual `Terminar ejercicio`.
7. Al terminar, suma puntos, actualiza el saldo y genera un ticket imprimible.
8. El calendario muestra qué días hubo actividad, qué ejercicios se hicieron, cuántas repeticiones y cuántos puntos se obtuvieron.

## Ejercicios soportados por IA

- `squat`: sentadillas
- `arms`: elevación de brazos
- `knees`: rodillas al pecho
- `side`: flexión lateral

## Dependencias principales

- `fastapi`
- `uvicorn`
- `sqlalchemy`
- `opencv-python`
- `mediapipe`
- `numpy`
