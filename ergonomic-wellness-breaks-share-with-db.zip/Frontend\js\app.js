const videoElement = document.querySelector(".input_video");
const canvasElement = document.querySelector(".output_canvas");
const canvasCtx = canvasElement.getContext("2d");

const cursor = document.getElementById("gestureCursor");
const appViewport = document.getElementById("appViewport");
const instructionOverlay = document.getElementById("instructionOverlay");
const instructionCard = document.querySelector(".instruction-card");
const calendarOverlay = document.getElementById("calendarOverlay");
const calendarPanel = document.querySelector(".calendar-panel");
const rewardsOverlay = document.getElementById("rewardsOverlay");
const rewardsPanel = document.querySelector(".rewards-panel");
const exerciseOverlay = document.getElementById("exerciseOverlay");
const readyBtn = document.getElementById("readyBtn");
const backBtn = document.getElementById("backBtn");
const finishExerciseBtn = document.getElementById("finishExerciseBtn");
const logoutBtn = document.getElementById("logoutBtn");
const calendarShortcutBtn = document.getElementById("calendarShortcutBtn");
const rewardsShortcutBtn = document.getElementById("rewardsShortcutBtn");
const backToAdminBtn = document.getElementById("backToAdminBtn");
const previewModeBadge = document.getElementById("previewModeBadge");

const exerciseGrid = document.getElementById("exerciseGrid");
const targetOptions = document.getElementById("targetOptions");
const rewardOverlayList = document.getElementById("rewardOverlayList");
const rewardsSummary = document.getElementById("rewardsSummary");
const rewardsPageIndicator = document.getElementById("rewardsPageIndicator");
const rewardsPrev = document.getElementById("rewardsPrev");
const rewardsNext = document.getElementById("rewardsNext");
const rewardsClose = document.getElementById("rewardsClose");

const exerciseTitle = document.getElementById("exerciseTitle");
const exerciseImage = document.getElementById("exerciseImage");
const exerciseText = document.getElementById("exerciseText");
const selectedTargetLabel = document.getElementById("selectedTargetLabel");

const countdown = document.getElementById("countdown");
const currentUserName = document.getElementById("currentUserName");
const userPointsBox = document.getElementById("userPoints");
const currentExerciseLabel = document.getElementById("currentExercise");
const counter = document.getElementById("counter");
const goalIndicator = document.getElementById("goalIndicator");
const goalStatus = document.getElementById("goalStatus");
const exerciseFeedback = document.getElementById("exerciseFeedback");

const calendarMonthTitle = document.getElementById("calendarMonthTitle");
const calendarMonthSummary = document.getElementById("calendarMonthSummary");
const calendarLegend = document.getElementById("calendarLegend");
const calendarGrid = document.getElementById("calendarGrid");
const calendarSelectedDate = document.getElementById("calendarSelectedDate");
const calendarDayStats = document.getElementById("calendarDayStats");
const calendarDetailsList = document.getElementById("calendarDetailsList");
const calendarPrev = document.getElementById("calendarPrev");
const calendarNext = document.getElementById("calendarNext");
const calendarClose = document.getElementById("calendarClose");

const resultMessage = document.getElementById("resultMessage");

const SESSION_KEYS = ["user", "role", "userId", "currentUser"];
const GESTURE_HOLD_MS = 1200;
const GESTURE_HOLD_SHORT_MS = 800;
const COUNTDOWN_SECONDS = 3;
const REWARDS_PER_PAGE = 4;
const WEEK_DAYS = ["Lun", "Mar", "Mie", "Jue", "Vie", "Sab", "Dom"];

let smoothX = 0.5;
let smoothY = 0.5;
let lastTime = performance.now();
let hoverTimerMap = new Map();

const SMOOTHING = 0.35;
const DEAD_ZONE = 0.005;
const GAIN = 1.8;

let exercises = [];
let rewards = [];
let currentExercise = null;
let currentUser = null;
let activeSession = null;
let lastTicket = null;
let frameRequestInFlight = false;
let apiFrame = 0;
let sessionStartedAt = null;
let selectedTargetReps = null;
let activeGoalReps = null;
let sessionLive = false;

let calendarState = {
  monthKey: "",
  days: new Map(),
  summary: null,
  legend: [],
  selectedDate: null,
  visible: false
};

let rewardsState = {
  visible: false,
  page: 0
};

function fitStageToViewport(stage, padding = 12) {
  if (!stage) return;

  stage.style.transform = "translateX(-50%) scale(1)";
  stage.style.top = "0px";

  const naturalWidth = stage.offsetWidth;
  const naturalHeight = stage.offsetHeight;
  const availableWidth = Math.max(320, window.innerWidth - padding * 2);
  const availableHeight = Math.max(320, window.innerHeight - padding * 2);
  const scale = Math.min(availableWidth / naturalWidth, availableHeight / naturalHeight, 1);
  const topOffset = Math.max(padding, Math.floor((window.innerHeight - naturalHeight * scale) / 2));

  stage.style.top = `${topOffset}px`;
  stage.style.transform = `translateX(-50%) scale(${scale})`;
}

function fitOverlayPanel(panel, padding = 18) {
  if (!panel || panel.offsetParent === null) return;

  panel.style.transform = "scale(1)";
  const naturalWidth = panel.offsetWidth;
  const naturalHeight = panel.offsetHeight;
  const scale = Math.min(
    (window.innerWidth - padding * 2) / naturalWidth,
    (window.innerHeight - padding * 2) / naturalHeight,
    1
  );

  panel.style.transform = `scale(${scale})`;
}

function fitViewportLayout() {
  fitStageToViewport(appViewport);
  fitOverlayPanel(instructionCard);
  fitOverlayPanel(calendarPanel);
  fitOverlayPanel(rewardsPanel);
}

function setHtml(element, html) {
  if (!element) return false;
  element.innerHTML = html;
  return true;
}

function setText(element, value) {
  if (!element) return false;
  element.innerText = value;
  return true;
}

function setNodeText(element, value) {
  if (!element) return false;
  element.textContent = value;
  return true;
}

function setDisplay(element, value) {
  if (!element) return false;
  element.style.display = value;
  return true;
}

function validateBootDom() {
  const required = {
    cursor,
    appViewport,
    instructionOverlay,
    calendarOverlay,
    rewardsOverlay,
    exerciseOverlay,
    currentUserName,
    userPointsBox,
    exerciseGrid,
    resultMessage,
    countdown,
    currentExerciseLabel,
    counter,
    goalIndicator,
    goalStatus,
    exerciseFeedback,
    rewardOverlayList,
    rewardsSummary,
    rewardsPageIndicator,
    calendarMonthTitle,
    calendarMonthSummary,
    calendarLegend,
    calendarGrid,
    calendarSelectedDate,
    calendarDayStats,
    calendarDetailsList
  };

  const missing = Object.entries(required)
    .filter(([, element]) => !element)
    .map(([key]) => key);

  if (!missing.length) return true;

  const message = `La interfaz esta desactualizada o incompleta. Faltan elementos: ${missing.join(", ")}. Recarga la pagina con Ctrl+F5.`;
  console.error(message);

  if (resultMessage) {
    setHtml(resultMessage, `
      <div class="result-card error">
        <h3>No se pudo cargar la aplicacion</h3>
        <p>${message}</p>
      </div>
    `);
    resultMessage.classList.add("show");
  } else {
    alert(message);
  }

  return false;
}

function getApi() {
  return window.WellnessAPI;
}

function normalizeUser(user) {
  if (!user) return null;
  return {
    id: Number(user.id),
    name: user.nombre || user.name,
    role: user.role,
    points: Number(user.points_balance ?? user.points ?? 0),
    totalPoints: Number(user.points_earned ?? user.totalPoints ?? 0)
  };
}

function getStoredUser() {
  const raw = localStorage.getItem("currentUser");
  if (raw) {
    try {
      return normalizeUser(JSON.parse(raw));
    } catch (error) {
      console.warn("No se pudo leer currentUser", error);
    }
  }

  const userId = localStorage.getItem("userId");
  const userName = localStorage.getItem("user");
  const role = localStorage.getItem("role");

  if (!userId || !userName || !role) return null;
  return {
    id: Number(userId),
    name: userName,
    role,
    points: 0,
    totalPoints: 0
  };
}

function persistUser(user) {
  localStorage.setItem("user", user.name);
  localStorage.setItem("role", user.role);
  localStorage.setItem("userId", String(user.id));
  localStorage.setItem("currentUser", JSON.stringify(user));
}

function clearSession() {
  SESSION_KEYS.forEach(key => localStorage.removeItem(key));
}

function logout() {
  clearSession();
  window.location.href = "login.html";
}

function isAdminPreviewMode() {
  if (!currentUser || currentUser.role !== "admin") {
    return false;
  }

  const params = new URLSearchParams(window.location.search);
  return params.get("preview") === "user";
}

function goBackToAdminPanel() {
  window.location.href = "admin.html";
}

function renderPreviewModeState() {
  const previewActive = isAdminPreviewMode();

  if (backToAdminBtn) {
    setDisplay(backToAdminBtn, previewActive ? "inline-flex" : "none");
  }

  if (previewModeBadge) {
    setDisplay(previewModeBadge, previewActive ? "inline-flex" : "none");
  }
}

function renderUserSummary() {
  if (!currentUser || !currentUserName || !userPointsBox) return;
  setText(currentUserName, currentUser.name);
  setText(userPointsBox, `Puntos: ${currentUser.points}`);
  renderPreviewModeState();
  updateRewardShortcut();
  fitViewportLayout();
}

function renderMenuOptions() {
  if (!exerciseGrid) {
    console.warn("No se encontro exerciseGrid");
    return;
  }

  setHtml(exerciseGrid, "");

  if (!exercises.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No hay ejercicios activos.";
    exerciseGrid.appendChild(empty);
    fitViewportLayout();
    return;
  }

  exercises.forEach(exercise => {
    const button = document.createElement("button");
    button.type = "button";
    button.classList.add("menu-option");
    button.dataset.optionType = "exercise";
    button.dataset.exerciseId = String(exercise.id);
    button.style.setProperty("--exercise-color", exercise.color_hex || "#38bdf8");

    button.innerHTML = `
      <img src="${exercise.image_path || "/Resources/images/squat.jpg"}" alt="${exercise.nombre}">
      <p>${exercise.nombre}</p>
      <span>${exercise.puntos_por_rep} pts/rep</span>
    `;

    button.addEventListener("click", () => {
      showInstructionsById(exercise.id);
    });

    exerciseGrid.appendChild(button);
  });

  fitViewportLayout();
}

function updateRewardShortcut() {
  if (!rewardsShortcutBtn) return;

  rewardsShortcutBtn.classList.remove("header-shortcut-ready");
  rewardsShortcutBtn.title = "Recompensas";

  if (!rewards.length) {
    return;
  }

  const availableRewards = rewards.filter(reward => reward.stock === null || reward.stock > 0);
  if (!availableRewards.length) {
    rewardsShortcutBtn.title = "Sin stock disponible";
    return;
  }

  const lowestCost = Math.min(...availableRewards.map(reward => Number(reward.costo_puntos || 0)));
  if (!currentUser) {
    rewardsShortcutBtn.title = `${availableRewards.length} disponibles`;
    return;
  }

  const canRedeem = availableRewards.filter(reward => currentUser.points >= reward.costo_puntos).length;
  if (canRedeem > 0) {
    rewardsShortcutBtn.classList.add("header-shortcut-ready");
    rewardsShortcutBtn.title = `${canRedeem} listas para canjear`;
  } else {
    rewardsShortcutBtn.title = `Desde ${lowestCost} puntos`;
  }
}

function getRewardPageCount() {
  return Math.max(1, Math.ceil(rewards.length / REWARDS_PER_PAGE));
}

function renderRewards() {
  updateRewardShortcut();
  renderRewardsOverlay();
  fitViewportLayout();
}

function renderRewardsOverlay() {
  if (!rewardOverlayList || !rewardsSummary || !rewardsPageIndicator || !rewardsPrev || !rewardsNext) {
    console.warn("No se encontro el overlay de recompensas completo");
    return;
  }

  setHtml(rewardOverlayList, "");

  if (!rewards.length) {
    setText(rewardsSummary, "No hay recompensas disponibles en este momento.");
    setText(rewardsPageIndicator, "Pagina 1 de 1");
    rewardsPrev.disabled = true;
    rewardsNext.disabled = true;
    setHtml(rewardOverlayList, "<p class='empty-state'>No hay recompensas disponibles.</p>");
    fitViewportLayout();
    return;
  }

  const pageCount = getRewardPageCount();
  rewardsState.page = Math.max(0, Math.min(rewardsState.page, pageCount - 1));

  const availableRewards = rewards.filter(reward => reward.stock === null || reward.stock > 0);
  const redeemableCount = currentUser
    ? availableRewards.filter(reward => currentUser.points >= reward.costo_puntos).length
    : 0;

  setText(
    rewardsSummary,
    currentUser
      ? `Saldo: ${currentUser.points} puntos. ${redeemableCount} recompensas canjeables.`
      : "Selecciona una recompensa para canjearla."
  );
  setText(rewardsPageIndicator, `Pagina ${rewardsState.page + 1} de ${pageCount}`);
  rewardsPrev.disabled = rewardsState.page === 0;
  rewardsNext.disabled = rewardsState.page >= pageCount - 1;

  const pageStart = rewardsState.page * REWARDS_PER_PAGE;
  const pageRewards = rewards.slice(pageStart, pageStart + REWARDS_PER_PAGE);

  pageRewards.forEach(reward => {
    const card = document.createElement("div");
    card.classList.add("reward-card");

    const enoughPoints = currentUser && currentUser.points >= reward.costo_puntos;
    const hasStock = reward.stock === null || reward.stock > 0;

    card.innerHTML = `
      <h3>${reward.nombre}</h3>
      <p class="reward-description">${reward.descripcion}</p>
      <div class="reward-meta">
        <span>${reward.costo_puntos} puntos</span>
        <span>${reward.stock === null ? "Stock libre" : `Stock: ${reward.stock}`}</span>
      </div>
      <button class="reward-btn" data-reward-id="${reward.id}" ${(!enoughPoints || !hasStock) ? "disabled" : ""}>
        ${hasStock ? "Canjear" : "Sin stock"}
      </button>
    `;

    rewardOverlayList.appendChild(card);
  });

  rewardOverlayList.querySelectorAll(".reward-btn").forEach(button => {
    button.addEventListener("click", async () => {
      const rewardId = Number(button.dataset.rewardId);
      await redeemReward(rewardId);
    });
  });

  fitViewportLayout();
}

function openRewards() {
  if (activeSession) return;

  closeCalendar(true);
  rewardsState.visible = true;
  setDisplay(rewardsOverlay, "flex");
  renderRewardsOverlay();
  fitViewportLayout();
}

function closeRewards(skipFit = false) {
  rewardsState.visible = false;
  setDisplay(rewardsOverlay, "none");
  if (!skipFit) {
    fitViewportLayout();
  }
}

function changeRewardsPage(delta) {
  const pageCount = getRewardPageCount();
  const nextPage = Math.max(0, Math.min(rewardsState.page + delta, pageCount - 1));
  if (nextPage === rewardsState.page) return;

  rewardsState.page = nextPage;
  renderRewardsOverlay();
}

function buildTargetChoices(exercise) {
  const suggested = Number(exercise.objetivo_reps || 10);
  const numericChoices = [suggested, 5, 10, 15, 20]
    .filter((value, index, list) => value > 0 && list.indexOf(value) === index)
    .sort((a, b) => a - b);

  return [
    { label: `Sugerida ${suggested}`, value: suggested },
    ...numericChoices
      .filter(value => value !== suggested)
      .map(value => ({ label: `${value} reps`, value })),
    { label: "Libre", value: null }
  ];
}

function renderTargetOptions() {
  if (!currentExercise || !targetOptions) return;

  const choices = buildTargetChoices(currentExercise);
  setHtml(targetOptions, "");

  choices.forEach(choice => {
    const button = document.createElement("button");
    button.className = "target-option";
    button.dataset.targetValue = choice.value === null ? "free" : String(choice.value);
    button.textContent = choice.label;
    if ((choice.value === null && selectedTargetReps === null) || choice.value === selectedTargetReps) {
      button.classList.add("selected");
    }
    button.addEventListener("click", () => {
      selectedTargetReps = choice.value;
      renderTargetOptions();
      renderSelectedTargetLabel();
    });
    targetOptions.appendChild(button);
  });
}

function renderSelectedTargetLabel() {
  if (selectedTargetReps === null) {
    setNodeText(selectedTargetLabel, "Meta libre: termina cuando quieras.");
    return;
  }
  setNodeText(selectedTargetLabel, `Meta seleccionada: ${selectedTargetReps} repeticiones.`);
}

function showInstructionsById(exerciseId) {
  if (activeSession) return;
  currentExercise = exercises.find(item => item.id === Number(exerciseId)) || null;
  if (!currentExercise) return;

  selectedTargetReps = Number(currentExercise.objetivo_reps || 10);
  setText(exerciseTitle, currentExercise.nombre);
  exerciseImage.src = currentExercise.image_path || "/Resources/images/squat.jpg";
  setText(exerciseText, `${currentExercise.descripcion} - ${currentExercise.puntos_por_rep} puntos por repeticion`);
  renderTargetOptions();
  renderSelectedTargetLabel();
  setDisplay(instructionOverlay, "flex");
  fitViewportLayout();
}

function goBackToMenu() {
  if (activeSession) return;
  setDisplay(instructionOverlay, "none");
  currentExercise = null;
  fitViewportLayout();
}

function showMessage(html, autoHideMs = 4500) {
  if (!resultMessage) {
    console.error("No se encontro resultMessage", html);
    return;
  }

  window.clearTimeout(showMessage.hideTimer);
  setHtml(resultMessage, html);
  resultMessage.classList.add("show");

  if (autoHideMs > 0) {
    showMessage.hideTimer = window.setTimeout(() => {
      resultMessage.classList.remove("show");
    }, autoHideMs);
  }
}

function dismissResultMessage() {
  if (!resultMessage) return;
  window.clearTimeout(showMessage.hideTimer);
  resultMessage.classList.remove("show");
  window.setTimeout(() => {
    if (!resultMessage.classList.contains("show")) {
      setHtml(resultMessage, "");
    }
  }, 180);
}

function showTicketResult(response) {
  lastTicket = response.ticket;
  showMessage(`
    <div class="result-card">
      <h3>Ejercicio completado</h3>
      <p>Repeticiones validas: <b>${response.session.total_reps}</b></p>
      <p>Puntos ganados: <b>${response.session.points_earned}</b></p>
      <p>Puntos acumulados: <b>${currentUser.points}</b></p>
      <div class="result-actions">
        <button id="printTicketBtn" class="ticket-btn result-action-btn">Imprimir ticket</button>
        <button id="dismissResultBtn" class="result-secondary-btn result-action-btn">Cerrar</button>
      </div>
    </div>
  `, 0);

  const printButton = document.getElementById("printTicketBtn");
  const dismissButton = document.getElementById("dismissResultBtn");

  printButton?.addEventListener("click", () => printTicket(lastTicket));
  dismissButton?.addEventListener("click", dismissResultMessage);
}

function printTicket(ticket) {
  const popup = window.open("", "_blank", "width=420,height=640");
  if (!popup) {
    showMessage("<div class='result-card'><h3>No se pudo abrir la ventana de impresion</h3><p>Permite ventanas emergentes para imprimir el ticket.</p></div>");
    return;
  }

  popup.document.write(`
    <html>
      <head>
        <title>Ticket de Puntos</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 24px; color: #0f172a; }
          .ticket { border: 2px dashed #0f172a; padding: 24px; border-radius: 14px; }
          h1 { font-size: 22px; margin: 0 0 18px; }
          p { margin: 8px 0; font-size: 16px; }
          .total { margin-top: 18px; font-size: 18px; font-weight: bold; }
        </style>
      </head>
      <body onload="window.print(); window.close();">
        <div class="ticket">
          <h1>Ticket de Corporate Active Break</h1>
          <p>Usuario: ${ticket.user_name}</p>
          <p>Ejercicio: ${ticket.exercise_name}</p>
          <p>Repeticiones validas: ${ticket.reps}</p>
          <p>Puntos ganados: ${ticket.points_earned}</p>
          <p class="total">Puntos acumulados: ${ticket.points_balance}</p>
          <p>Fecha: ${new Date(ticket.printed_at).toLocaleString("es-MX")}</p>
        </div>
      </body>
    </html>
  `);
  popup.document.close();
}

async function loadRewards() {
  const response = await getApi().getRewards();
  rewards = response.rewards || [];
  renderRewards();
}

async function loadInitialData() {
  currentUser = getStoredUser();
  if (!currentUser || !currentUser.id) {
    logout();
    return;
  }

  const [userResponse, exerciseResponse, rewardResponse] = await Promise.all([
    getApi().getUser(currentUser.id),
    getApi().getExercises(),
    getApi().getRewards()
  ]);

  currentUser = normalizeUser(userResponse.user);
  persistUser(currentUser);
  exercises = exerciseResponse.exercises || [];
  rewards = rewardResponse.rewards || [];

  renderUserSummary();
  renderMenuOptions();
  renderRewards();
}

async function redeemReward(rewardId) {
  if (!currentUser) return;

  try {
    const response = await getApi().redeemReward(currentUser.id, rewardId);
    currentUser = normalizeUser(response.user);
    persistUser(currentUser);
    renderUserSummary();
    await loadRewards();

    showMessage(`
      <div class="result-card">
        <h3>Recompensa canjeada</h3>
        <p>${response.redemption.reward_name}</p>
        <p>Puntos usados: <b>${response.redemption.points_spent}</b></p>
        <p>Saldo disponible: <b>${currentUser.points}</b></p>
      </div>
    `);
  } catch (error) {
    showMessage(`
      <div class="result-card error">
        <h3>No fue posible canjear</h3>
        <p>${error.message}</p>
      </div>
    `);
  }
}

function resetExerciseUi() {
  setText(counter, "0");
  setText(goalIndicator, activeGoalReps === null ? "Libre" : `${activeGoalReps} reps`);
  setText(
    goalStatus,
    activeGoalReps === null
      ? "Modo libre: finaliza cuando ya no quieras continuar."
      : `Objetivo activo: ${activeGoalReps} repeticiones.`
  );
  goalStatus.classList.remove("goal-done");
  setText(exerciseFeedback, "Manten todo el cuerpo visible en la camara.");
  finishExerciseBtn.disabled = true;
}

async function startExerciseSession() {
  if (!currentExercise || !currentUser || activeSession) return;

  try {
    const response = await getApi().startSession(currentUser.id, currentExercise.id);
    activeSession = response.session;
    activeGoalReps = selectedTargetReps;
    sessionStartedAt = Date.now();
    sessionLive = false;

    resetExerciseUi();
    dismissResultMessage();
    closeCalendar(true);
    closeRewards(true);
    setDisplay(instructionOverlay, "none");
    setText(currentExerciseLabel, currentExercise.nombre);
    setDisplay(exerciseOverlay, "block");
    fitViewportLayout();

    let t = COUNTDOWN_SECONDS;
    setDisplay(countdown, "block");
    setText(countdown, t);

    const countdownInterval = window.setInterval(() => {
      t -= 1;
      setText(countdown, t);

      if (t <= 0) {
        window.clearInterval(countdownInterval);
        setDisplay(countdown, "none");
        sessionLive = true;
        finishExerciseBtn.disabled = false;
      }
    }, 1000);
  } catch (error) {
    showMessage(`
      <div class="result-card error">
        <h3>No se pudo iniciar la sesion</h3>
        <p>${error.message}</p>
      </div>
    `);
  }
}

async function endExercise() {
  if (!activeSession) return;

  setDisplay(exerciseOverlay, "none");
  fitViewportLayout();

  try {
    const duration = Math.max(1, Math.round((Date.now() - sessionStartedAt) / 1000));
    const response = await getApi().completeSession(activeSession.id, duration);
    currentUser = normalizeUser(response.user);
    persistUser(currentUser);
    renderUserSummary();
    await loadRewards();

    showTicketResult(response);
  } catch (error) {
    showMessage(`
      <div class="result-card error">
        <h3>No se pudo cerrar la sesion</h3>
        <p>${error.message}</p>
      </div>
    `);
  } finally {
    activeSession = null;
    currentExercise = null;
    activeGoalReps = null;
    sessionStartedAt = null;
    sessionLive = false;
    frameRequestInFlight = false;
    finishExerciseBtn.disabled = false;
  }
}

function getCurrentMonthKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

function getTodayKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}

function parseMonthKey(monthKey) {
  const [year, month] = monthKey.split("-").map(Number);
  return new Date(year, month - 1, 1);
}

function monthLabel(monthKey) {
  const date = parseMonthKey(monthKey);
  return date.toLocaleDateString("es-MX", {
    month: "long",
    year: "numeric"
  });
}

function addMonth(monthKey, delta) {
  const date = parseMonthKey(monthKey);
  date.setMonth(date.getMonth() + delta);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

async function loadCalendarMonth(monthKey) {
  if (!currentUser) return;

  const response = await getApi().getUserHistory(currentUser.id, monthKey);
  calendarState.monthKey = response.month;
  calendarState.summary = response.summary;
  calendarState.legend = response.legend || [];
  calendarState.days = new Map((response.days || []).map(day => [day.date, day]));

  const todayKey = getTodayKey();
  const availableDates = Array.from(calendarState.days.keys()).sort();
  if (calendarState.days.has(todayKey) && todayKey.startsWith(calendarState.monthKey)) {
    calendarState.selectedDate = todayKey;
  } else if (calendarState.days.has(calendarState.selectedDate)) {
    calendarState.selectedDate = calendarState.selectedDate;
  } else {
    calendarState.selectedDate = availableDates[availableDates.length - 1] || `${calendarState.monthKey}-01`;
  }

  renderCalendar();
}

function renderCalendar() {
  if (!calendarMonthTitle || !calendarMonthSummary || !calendarLegend || !calendarGrid) {
    console.warn("No se encontro el panel del calendario");
    return;
  }

  setText(calendarMonthTitle, `Calendario de ${monthLabel(calendarState.monthKey)}`);

  if (calendarState.summary) {
    setText(
      calendarMonthSummary,
      `${calendarState.summary.active_days} dias activos - ${calendarState.summary.total_sessions} sesiones - ${calendarState.summary.total_points} puntos`
    );
  } else {
    setText(calendarMonthSummary, "Sin registros para este mes.");
  }

  setHtml(calendarLegend, "");
  calendarState.legend.forEach(item => {
    const legendItem = document.createElement("div");
    legendItem.className = "legend-item";
    legendItem.innerHTML = `
      <span class="legend-color" style="background:${item.color_hex};"></span>
      <span>${item.nombre}</span>
    `;
    calendarLegend.appendChild(legendItem);
  });

  setHtml(calendarGrid, "");
  WEEK_DAYS.forEach(day => {
    const header = document.createElement("div");
    header.className = "calendar-weekday";
    header.textContent = day;
    calendarGrid.appendChild(header);
  });

  const monthDate = parseMonthKey(calendarState.monthKey);
  const year = monthDate.getFullYear();
  const monthIndex = monthDate.getMonth();
  const firstDay = new Date(year, monthIndex, 1);
  const offset = (firstDay.getDay() + 6) % 7;
  const totalDays = new Date(year, monthIndex + 1, 0).getDate();

  for (let blank = 0; blank < offset; blank += 1) {
    const spacer = document.createElement("div");
    spacer.className = "calendar-blank";
    calendarGrid.appendChild(spacer);
  }

  for (let day = 1; day <= totalDays; day += 1) {
    const dateKey = `${calendarState.monthKey}-${String(day).padStart(2, "0")}`;
    const info = calendarState.days.get(dateKey);
    const cell = document.createElement("button");
    cell.className = "calendar-day";
    cell.dataset.date = dateKey;
    if (calendarState.selectedDate === dateKey) {
      cell.classList.add("selected");
    }
    if (info) {
      cell.classList.add("has-sessions");
    }

    const dots = info
      ? info.sessions
          .map(session => `<span class="calendar-dot" style="background:${session.exercise_color};"></span>`)
          .join("")
      : "";

    cell.innerHTML = `
      <span class="calendar-day-number">${day}</span>
      <span class="calendar-day-mini">${info ? `${info.total_reps} reps` : "Sin actividad"}</span>
      <span class="calendar-dots">${dots}</span>
    `;
    cell.addEventListener("click", () => selectCalendarDate(dateKey));
    calendarGrid.appendChild(cell);
  }

  renderCalendarDayDetails();
  fitViewportLayout();
}

function selectCalendarDate(dateKey) {
  calendarState.selectedDate = dateKey;
  renderCalendar();
}

function renderCalendarDayDetails() {
  if (!calendarSelectedDate || !calendarDayStats || !calendarDetailsList) {
    console.warn("No se encontro el detalle del calendario");
    return;
  }

  const info = calendarState.days.get(calendarState.selectedDate);
  if (!calendarState.selectedDate) {
    setText(calendarSelectedDate, "Selecciona un dia");
    setHtml(calendarDayStats, "");
    setHtml(calendarDetailsList, "<p class='empty-state'>No hay informacion para mostrar.</p>");
    return;
  }

  const selectedDate = new Date(`${calendarState.selectedDate}T12:00:00`);
  setText(calendarSelectedDate, selectedDate.toLocaleDateString("es-MX", {
    weekday: "long",
    day: "numeric",
    month: "long"
  }));

  if (!info) {
    setHtml(calendarDayStats, "<p>Sin ejercicio registrado este dia.</p>");
    setHtml(calendarDetailsList, "<p class='empty-state'>No hubo sesiones completadas.</p>");
    return;
  }

  setHtml(calendarDayStats, `
    <div class="day-stat-card">
      <strong>${info.total_reps}</strong>
      <span>reps</span>
    </div>
    <div class="day-stat-card">
      <strong>${info.total_points}</strong>
      <span>puntos</span>
    </div>
    <div class="day-stat-card">
      <strong>${info.sessions.length}</strong>
      <span>sesiones</span>
    </div>
  `);

  setHtml(calendarDetailsList, "");
  info.sessions.forEach(session => {
    const item = document.createElement("div");
    item.className = "calendar-session-item";
    item.innerHTML = `
      <div class="calendar-session-head">
        <span class="session-color" style="background:${session.exercise_color};"></span>
        <strong>${session.exercise_name}</strong>
      </div>
      <p>${session.reps} repeticiones - ${session.points_earned} puntos</p>
      <p>Duracion: ${session.duration_seconds}s - ${session.started_label}</p>
    `;
    calendarDetailsList.appendChild(item);
  });
}

async function openCalendar() {
  if (activeSession) return;

  closeRewards(true);
  calendarState.visible = true;
  setDisplay(calendarOverlay, "flex");
  await loadCalendarMonth(calendarState.monthKey || getCurrentMonthKey());
  fitViewportLayout();
}

function closeCalendar(skipFit = false) {
  calendarState.visible = false;
  setDisplay(calendarOverlay, "none");
  if (!skipFit) {
    fitViewportLayout();
  }
}

async function changeCalendarMonth(delta) {
  const target = addMonth(calendarState.monthKey || getCurrentMonthKey(), delta);
  await loadCalendarMonth(target);
}

function processGestureElements(elements, x, y, delta, threshold, onActivate) {
  elements.forEach(element => {
    if (!element) return;
    if (element.disabled) {
      hoverTimerMap.set(element, 0);
      element.classList.remove("active");
      return;
    }

    const rect = element.getBoundingClientRect();
    const inside = x > rect.left && x < rect.right && y > rect.top && y < rect.bottom;

    if (inside) {
      const previous = hoverTimerMap.get(element) || 0;
      const next = previous + delta;
      hoverTimerMap.set(element, next);
      element.classList.add("active");

      if (next > threshold) {
        hoverTimerMap.set(element, 0);
        onActivate(element);
      }
    } else {
      hoverTimerMap.set(element, 0);
      element.classList.remove("active");
    }
  });
}

function gestureNavigation(landmarks) {
  const now = performance.now();
  const delta = now - lastTime;
  lastTime = now;

  const hand = landmarks[20];
  let targetX = (hand.x - 0.5) * GAIN + 0.5;
  let targetY = (hand.y - 0.5) * GAIN + 0.5;

  targetX = Math.max(0, Math.min(1, targetX));
  targetY = Math.max(0, Math.min(1, targetY));

  if (Math.abs(targetX - smoothX) < DEAD_ZONE) targetX = smoothX;
  if (Math.abs(targetY - smoothY) < DEAD_ZONE) targetY = smoothY;

  smoothX += (targetX - smoothX) * SMOOTHING;
  smoothY += (targetY - smoothY) * SMOOTHING;

  const x = smoothX * window.innerWidth;
  const y = smoothY * window.innerHeight;

  cursor.style.left = `${x}px`;
  cursor.style.top = `${y}px`;

  if (resultMessage.classList.contains("show")) {
    processGestureElements(
      Array.from(resultMessage.querySelectorAll("button")),
      x,
      y,
      delta,
      GESTURE_HOLD_MS,
      element => element.click()
    );
  } else if (rewardsState.visible) {
    processGestureElements(
      [rewardsPrev, rewardsNext, rewardsClose].filter(Boolean),
      x,
      y,
      delta,
      GESTURE_HOLD_MS,
      element => element.click()
    );

    processGestureElements(
      Array.from(document.querySelectorAll(".reward-btn:not(:disabled)")),
      x,
      y,
      delta,
      GESTURE_HOLD_MS,
      element => element.click()
    );
  } else if (calendarState.visible) {
    processGestureElements(
      [calendarPrev, calendarNext, calendarClose].filter(Boolean),
      x,
      y,
      delta,
      GESTURE_HOLD_MS,
      element => element.click()
    );

    processGestureElements(
      Array.from(document.querySelectorAll(".calendar-day")),
      x,
      y,
      delta,
      GESTURE_HOLD_SHORT_MS,
      element => element.click()
    );
  } else if (instructionOverlay.style.display === "flex" && !activeSession) {
    processGestureElements(
      [readyBtn, backBtn].filter(Boolean),
      x,
      y,
      delta,
      GESTURE_HOLD_MS,
      element => element.click()
    );

    processGestureElements(
      Array.from(document.querySelectorAll(".target-option")),
      x,
      y,
      delta,
      GESTURE_HOLD_SHORT_MS,
      element => element.click()
    );
  } else if (activeSession) {
    if (sessionLive) {
      processGestureElements(
        [finishExerciseBtn].filter(Boolean),
        x,
        y,
        delta,
        GESTURE_HOLD_MS,
        element => element.click()
      );
    }
  } else {
    processGestureElements(
      [backToAdminBtn, calendarShortcutBtn, rewardsShortcutBtn].filter(Boolean),
      x,
      y,
      delta,
      GESTURE_HOLD_MS,
      element => element.click()
    );

    processGestureElements(
      Array.from(document.querySelectorAll(".menu-option")),
      x,
      y,
      delta,
      GESTURE_HOLD_MS,
      element => element.click()
    );
  }

  if (!resultMessage.classList.contains("show") && !rewardsState.visible && !calendarState.visible && instructionOverlay.style.display !== "flex" && !activeSession) {
    processGestureElements([logoutBtn].filter(Boolean), x, y, delta, GESTURE_HOLD_MS, element => element.click());
  }
}

async function processExercise(landmarks) {
  if (!activeSession || !sessionLive || frameRequestInFlight) return;

  frameRequestInFlight = true;
  try {
    const data = await getApi().processFrame(activeSession.id, landmarks);
    setText(counter, data.reps);
    setText(exerciseFeedback, data.feedback);

    if (activeGoalReps === null) {
      setText(goalStatus, "Modo libre: finaliza cuando quieras.");
      goalStatus.classList.remove("goal-done");
      return;
    }

    if (data.reps >= activeGoalReps) {
      setText(goalStatus, "Objetivo alcanzado. Puedes seguir o finalizar.");
      goalStatus.classList.add("goal-done");
    } else {
      setText(goalStatus, `Progreso: ${data.reps}/${activeGoalReps} repeticiones.`);
      goalStatus.classList.remove("goal-done");
    }
  } catch (error) {
    setText(exerciseFeedback, error.message);
  } finally {
    frameRequestInFlight = false;
  }
}

function onResults(results) {
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  canvasCtx.drawImage(results.image, 0, 0, canvasElement.width, canvasElement.height);

  if (results.poseLandmarks) {
    gestureNavigation(results.poseLandmarks);
    apiFrame += 1;

    if (activeSession && apiFrame % 6 === 0 && countdown.style.display === "none") {
      processExercise(results.poseLandmarks);
    }
  }
}

const pose = new Pose({
  locateFile: file => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`
});

pose.setOptions({
  modelComplexity: 1,
  smoothLandmarks: true,
  minDetectionConfidence: 0.7,
  minTrackingConfidence: 0.7
});

pose.onResults(onResults);

const camera = new Camera(videoElement, {
  onFrame: async () => {
    await pose.send({ image: videoElement });
  },
  width: 1280,
  height: 720
});

readyBtn?.addEventListener("click", startExerciseSession);
backBtn?.addEventListener("click", goBackToMenu);
finishExerciseBtn?.addEventListener("click", endExercise);
logoutBtn?.addEventListener("click", logout);
calendarShortcutBtn?.addEventListener("click", openCalendar);
rewardsShortcutBtn?.addEventListener("click", openRewards);
calendarPrev?.addEventListener("click", () => changeCalendarMonth(-1));
calendarNext?.addEventListener("click", () => changeCalendarMonth(1));
calendarClose?.addEventListener("click", closeCalendar);
rewardsPrev?.addEventListener("click", () => changeRewardsPage(-1));
rewardsNext?.addEventListener("click", () => changeRewardsPage(1));
rewardsClose?.addEventListener("click", closeRewards);
backToAdminBtn?.addEventListener("click", goBackToAdminPanel);
window.addEventListener("resize", fitViewportLayout);
window.addEventListener("orientationchange", fitViewportLayout);

(async function init() {
  try {
    if (!validateBootDom()) {
      return;
    }

    await loadInitialData();
    if (isAdminPreviewMode()) {
      showMessage(`
        <div class="result-card">
          <h3>Modo usuario de prueba</h3>
          <p>Estas usando tu misma cuenta de administrador para probar la experiencia del usuario.</p>
          <p>Las sesiones, puntos y canjes si afectan a tu cuenta real.</p>
        </div>
      `, 4200);
    }
    await camera.start();
    fitViewportLayout();
  } catch (error) {
    showMessage(`
      <div class="result-card error">
        <h3>No se pudo cargar la aplicacion</h3>
        <p>${error.message}</p>
      </div>
    `, 0);
  }
})();
