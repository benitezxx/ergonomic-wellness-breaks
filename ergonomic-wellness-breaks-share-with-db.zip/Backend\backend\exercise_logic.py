import math
from typing import Dict, List, Tuple

SUPPORTED_EXERCISES = {
    "squat": "Sentadillas",
    "arms": "Elevaciones de brazos",
    "knees": "Rodillas al pecho",
    "side": "Flexión lateral",
}

MIN_VALID_FRAMES = 3
MIN_VISIBILITY = 0.45


def default_session_state(exercise_code: str) -> Dict[str, float]:
    resting_state = {
        "squat": "UP",
        "arms": "DOWN",
        "knees": "DOWN",
        "side": "CENTER",
    }.get(exercise_code, "READY")
    return {
        "current_state": resting_state,
        "rep_count": 0,
        "valid_frames": 0,
        "last_metric": 0.0,
        "last_feedback": "Listo para comenzar.",
    }


def process_landmarks(exercise_code: str, landmarks: List[Dict], state: Dict[str, float]) -> Dict:
    if exercise_code == "squat":
        return _process_squat(landmarks, state)
    if exercise_code == "arms":
        return _process_arms(landmarks, state)
    if exercise_code == "knees":
        return _process_knees(landmarks, state)
    if exercise_code == "side":
        return _process_side_bend(landmarks, state)
    return _build_response(state, "READY", 0.0, "Ejercicio no soportado.", False, "metric")


def _process_squat(landmarks: List[Dict], state: Dict[str, float]) -> Dict:
    hip_r, knee_r, ankle_r = landmarks[24], landmarks[26], landmarks[28]
    hip_l, knee_l, ankle_l = landmarks[23], landmarks[25], landmarks[27]

    if not all(_visible(point) for point in (hip_r, knee_r, ankle_r, hip_l, knee_l, ankle_l)):
        return _missing_pose_response(state)

    angle_r = calculate_angle(hip_r, knee_r, ankle_r)
    angle_l = calculate_angle(hip_l, knee_l, ankle_l)
    knee_angle = round((angle_r + angle_l) / 2, 2)

    if knee_angle >= 160:
        position = "UP"
        feedback = "Vuelve a bajar para completar otra repetición."
    elif knee_angle <= 115:
        position = "DOWN"
        feedback = "Excelente profundidad, ahora sube."
    else:
        position = "MID"
        feedback = "Mantén el control del movimiento."

    updated_state, rep_completed = _update_state_cycle(
        state,
        position,
        resting_state="UP",
        active_state="DOWN",
        count_on_return=True,
    )
    return _build_response(updated_state, position, knee_angle, feedback, rep_completed, "angle")


def _process_arms(landmarks: List[Dict], state: Dict[str, float]) -> Dict:
    shoulder_l, wrist_l = landmarks[11], landmarks[15]
    shoulder_r, wrist_r = landmarks[12], landmarks[16]

    if not all(_visible(point) for point in (shoulder_l, wrist_l, shoulder_r, wrist_r)):
        return _missing_pose_response(state)

    raise_left = shoulder_l["y"] - wrist_l["y"]
    raise_right = shoulder_r["y"] - wrist_r["y"]
    raise_metric = round((raise_left + raise_right) / 2, 3)

    if raise_metric >= 0.08:
        position = "UP"
        feedback = "Brazos arriba, baja con control."
    elif raise_metric <= 0.02:
        position = "DOWN"
        feedback = "Ahora levanta ambos brazos por encima de los hombros."
    else:
        position = "MID"
        feedback = "Sigue elevando ambos brazos."

    updated_state, rep_completed = _update_state_cycle(
        state,
        position,
        resting_state="DOWN",
        active_state="UP",
        count_on_return=False,
    )
    return _build_response(updated_state, position, raise_metric, feedback, rep_completed, "lift")


def _process_knees(landmarks: List[Dict], state: Dict[str, float]) -> Dict:
    hip_l, knee_l = landmarks[23], landmarks[25]
    hip_r, knee_r = landmarks[24], landmarks[26]

    if not all(_visible(point) for point in (hip_l, knee_l, hip_r, knee_r)):
        return _missing_pose_response(state)

    knee_raise = round(max(hip_l["y"] - knee_l["y"], hip_r["y"] - knee_r["y"]), 3)

    if knee_raise >= 0.04:
        position = "UP"
        feedback = "Muy bien, alterna y sube otra rodilla."
    elif knee_raise <= 0.015:
        position = "DOWN"
        feedback = "Sube una rodilla hasta la altura de la cadera."
    else:
        position = "MID"
        feedback = "Eleva un poco más la rodilla."

    updated_state, rep_completed = _update_state_cycle(
        state,
        position,
        resting_state="DOWN",
        active_state="UP",
        count_on_return=False,
    )
    return _build_response(updated_state, position, knee_raise, feedback, rep_completed, "height")


def _process_side_bend(landmarks: List[Dict], state: Dict[str, float]) -> Dict:
    shoulder_l, shoulder_r = landmarks[11], landmarks[12]
    hip_l, hip_r = landmarks[23], landmarks[24]

    if not all(_visible(point) for point in (shoulder_l, shoulder_r, hip_l, hip_r)):
        return _missing_pose_response(state)

    shoulder_center = midpoint(shoulder_l, shoulder_r)
    hip_center = midpoint(hip_l, hip_r)
    lateral_shift = round(abs(shoulder_center["x"] - hip_center["x"]), 3)

    if lateral_shift >= 0.07:
        position = "BEND"
        feedback = "Buen alcance lateral, vuelve al centro."
    elif lateral_shift <= 0.03:
        position = "CENTER"
        feedback = "Inclina el torso hacia un costado."
    else:
        position = "MID"
        feedback = "Un poco más de inclinación lateral."

    updated_state, rep_completed = _update_state_cycle(
        state,
        position,
        resting_state="CENTER",
        active_state="BEND",
        count_on_return=True,
    )
    return _build_response(updated_state, position, lateral_shift, feedback, rep_completed, "offset")


def _update_state_cycle(
    state: Dict[str, float],
    position: str,
    *,
    resting_state: str,
    active_state: str,
    count_on_return: bool,
) -> Tuple[Dict[str, float], bool]:
    updated_state = dict(state)
    rep_completed = False

    current_state = updated_state.get("current_state", resting_state)
    valid_frames = int(updated_state.get("valid_frames", 0))
    rep_count = int(updated_state.get("rep_count", 0))

    if position == active_state:
        valid_frames += 1
        if current_state == resting_state and valid_frames >= MIN_VALID_FRAMES:
            current_state = active_state
            if not count_on_return:
                rep_count += 1
                rep_completed = True
                valid_frames = 0
    elif position == resting_state:
        if current_state == active_state and count_on_return:
            rep_count += 1
            rep_completed = True
        current_state = resting_state
        valid_frames = 0
    else:
        valid_frames = min(valid_frames, MIN_VALID_FRAMES)

    updated_state["current_state"] = current_state
    updated_state["rep_count"] = rep_count
    updated_state["valid_frames"] = valid_frames
    return updated_state, rep_completed


def calculate_angle(a: Dict, b: Dict, c: Dict) -> float:
    ba_x = a["x"] - b["x"]
    ba_y = a["y"] - b["y"]
    bc_x = c["x"] - b["x"]
    bc_y = c["y"] - b["y"]

    magnitude_ba = math.sqrt((ba_x * ba_x) + (ba_y * ba_y))
    magnitude_bc = math.sqrt((bc_x * bc_x) + (bc_y * bc_y))

    if magnitude_ba == 0 or magnitude_bc == 0:
        return 180.0

    cosine = ((ba_x * bc_x) + (ba_y * bc_y)) / (magnitude_ba * magnitude_bc)
    cosine = max(-1.0, min(1.0, cosine))
    return math.degrees(math.acos(cosine))


def midpoint(a: Dict, b: Dict) -> Dict[str, float]:
    return {"x": (a["x"] + b["x"]) / 2, "y": (a["y"] + b["y"]) / 2}


def _visible(point: Dict) -> bool:
    return bool(point) and point.get("visibility", 1) >= MIN_VISIBILITY


def _missing_pose_response(state: Dict[str, float]) -> Dict:
    return _build_response(
        state,
        state.get("current_state", "READY"),
        float(state.get("last_metric", 0.0)),
        "Ajusta tu postura para que la cámara vea todo el cuerpo.",
        False,
        "metric",
    )


def _build_response(
    state: Dict[str, float],
    position: str,
    metric: float,
    feedback: str,
    rep_completed: bool,
    metric_label: str,
) -> Dict:
    updated_state = dict(state)
    updated_state["last_metric"] = metric
    updated_state["last_feedback"] = feedback
    return {
        "state": updated_state,
        "position": position,
        "reps": int(updated_state.get("rep_count", 0)),
        "metric": metric,
        "metric_label": metric_label,
        "feedback": feedback,
        "rep_completed": rep_completed,
    }
