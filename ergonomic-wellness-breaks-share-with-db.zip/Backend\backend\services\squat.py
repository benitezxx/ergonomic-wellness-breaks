def validate_squat(angles):
    knee_angle = angles["knee"]

    if knee_angle > 150:
        position = "UP"

    elif knee_angle < 120:
        position = "DOWN"

    else:
        position = "TRANSITION"

    return {
        "position": position,
        "is_valid": True
    }