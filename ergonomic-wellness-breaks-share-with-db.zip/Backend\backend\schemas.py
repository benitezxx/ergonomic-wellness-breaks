from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class FaceRegisterRequest(BaseModel):
    nombre: str = Field(min_length=2, max_length=200)
    role: str = "user"
    embedding: Optional[List[float]] = None
    embeddings: List[List[float]] = Field(default_factory=list)
    image_path: Optional[str] = None


class FaceLoginRequest(BaseModel):
    embedding: Optional[List[float]] = None
    embeddings: List[List[float]] = Field(default_factory=list)


class ExercisePayload(BaseModel):
    codigo: str
    nombre: str = Field(min_length=2, max_length=100)
    descripcion: str = Field(min_length=5)
    image_path: Optional[str] = None
    color_hex: str = Field(min_length=4, max_length=20)
    puntos_por_rep: int = Field(ge=1, le=1000)
    objetivo_reps: int = Field(ge=1, le=500)
    duracion_segundos: int = Field(ge=10, le=600)
    activo: bool = True


class SessionStartRequest(BaseModel):
    user_id: int
    exercise_id: int


class SessionFrameRequest(BaseModel):
    landmarks: List[Dict]


class SessionFinishRequest(BaseModel):
    duracion_segundos: Optional[int] = Field(default=None, ge=1, le=3600)


class RewardRedemptionRequest(BaseModel):
    user_id: int
    reward_id: int


class RewardPayload(BaseModel):
    nombre: str = Field(min_length=2, max_length=120)
    descripcion: str = Field(min_length=5)
    costo_puntos: int = Field(ge=1, le=100000)
    stock: Optional[int] = Field(default=None, ge=0)
    activo: bool = True
