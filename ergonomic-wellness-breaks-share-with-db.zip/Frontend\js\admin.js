const SESSION_KEYS = ["user", "role", "userId", "currentUser"];

const adminViewport = document.getElementById("adminViewport");
const formTitle = document.getElementById("formTitle");
const exerciseIdInput = document.getElementById("exerciseId");
const codeInput = document.getElementById("code");
const pointsInput = document.getElementById("points");
const goalInput = document.getElementById("goal");
const nameInput = document.getElementById("name");
const descInput = document.getElementById("desc");
const imgInput = document.getElementById("img");
const colorInput = document.getElementById("color");
const activeInput = document.getElementById("active");
const list = document.getElementById("list");
const rewardFormTitle = document.getElementById("rewardFormTitle");
const rewardIdInput = document.getElementById("rewardId");
const rewardNameInput = document.getElementById("rewardName");
const rewardDescInput = document.getElementById("rewardDesc");
const rewardCostInput = document.getElementById("rewardCost");
const rewardStockInput = document.getElementById("rewardStock");
const rewardActiveInput = document.getElementById("rewardActive");
const rewardsAdminList = document.getElementById("rewardsAdminList");
const usersTableBody = document.getElementById("usersTableBody");
const leaderboard = document.getElementById("leaderboard");
const saveExerciseBtn = document.getElementById("saveExerciseBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");
const saveRewardBtn = document.getElementById("saveRewardBtn");
const cancelRewardEditBtn = document.getElementById("cancelRewardEditBtn");
const adminMessage = document.getElementById("adminMessage");
const logoutBtn = document.getElementById("logoutBtn");
const openUserModeBtn = document.getElementById("openUserModeBtn");
const adminStatusBadge = document.getElementById("adminStatusBadge");
const adminHeroTitle = document.getElementById("adminHeroTitle");
const adminHeroText = document.getElementById("adminHeroText");
const adminHeroMonth = document.getElementById("adminHeroMonth");
const adminLastUpdated = document.getElementById("adminLastUpdated");
const adminFaceCoverage = document.getElementById("adminFaceCoverage");
const analyticsMonthInput = document.getElementById("analyticsMonth");
const analyticsUserSelect = document.getElementById("analyticsUserSelect");
const totalUsersElement = document.getElementById("totalUsers");
const totalPointsElement = document.getElementById("totalPoints");
const totalSessionsElement = document.getElementById("totalSessions");
const topUserElement = document.getElementById("topUser");
const totalUsersMeta = document.getElementById("totalUsersMeta");
const totalPointsMeta = document.getElementById("totalPointsMeta");
const totalSessionsMeta = document.getElementById("totalSessionsMeta");
const topUserMeta = document.getElementById("topUserMeta");
const generalChartSummary = document.getElementById("generalChartSummary");
const generalChart = document.getElementById("generalChart");
const generalChartLegend = document.getElementById("generalChartLegend");
const generalDayDetails = document.getElementById("generalDayDetails");
const userChartSummary = document.getElementById("userChartSummary");
const userChart = document.getElementById("userChart");
const userChartLegend = document.getElementById("userChartLegend");
const userExerciseBreakdown = document.getElementById("userExerciseBreakdown");
const userRecentSessions = document.getElementById("userRecentSessions");
const workspaceTabs = Array.from(document.querySelectorAll(".workspace-tab"));
const workspacePanels = Array.from(document.querySelectorAll(".workspace-panel"));
const hasRewardsAdmin = Boolean(
  rewardFormTitle &&
  rewardIdInput &&
  rewardNameInput &&
  rewardDescInput &&
  rewardCostInput &&
  rewardStockInput &&
  rewardActiveInput &&
  rewardsAdminList &&
  saveRewardBtn &&
  cancelRewardEditBtn
);

const EXERCISE_PRESETS = {
  squat: { image: "/Resources/images/squat.jpg", color: "#38bdf8", goal: 12 },
  arms: { image: "/Resources/images/arms.jpg", color: "#22c55e", goal: 15 },
  knees: { image: "/Resources/images/knees.jpg", color: "#f59e0b", goal: 18 },
  side: { image: "/Resources/images/side.jpg", color: "#f97316", goal: 10 }
};

let exercises = [];
let rewards = [];
let editingExerciseId = null;
let editingRewardId = null;
let selectedAnalyticsUserId = null;
let activeAdminTab = "analytics";
let latestDashboardStats = null;
let latestGeneralAnalytics = null;
let latestAnalyticsMonth = "";

function fitAdminViewport() {
  if (!adminViewport) return;

  adminViewport.style.transform = "translateX(-50%) scale(1)";
  adminViewport.style.top = "0px";

  const naturalWidth = adminViewport.offsetWidth;
  const naturalHeight = adminViewport.offsetHeight;
  const padding = 12;
  const scale = Math.min(
    (window.innerWidth - padding * 2) / naturalWidth,
    (window.innerHeight - padding * 2) / naturalHeight,
    1
  );
  const topOffset = Math.max(padding, Math.floor((window.innerHeight - naturalHeight * scale) / 2));

  adminViewport.style.top = `${topOffset}px`;
  adminViewport.style.transform = `translateX(-50%) scale(${scale})`;
}

function setActiveAdminTab(tabName) {
  activeAdminTab = tabName;

  workspaceTabs.forEach(button => {
    button.classList.toggle("active", button.dataset.tab === tabName);
  });

  workspacePanels.forEach(panel => {
    panel.classList.toggle("active", panel.dataset.panel === tabName);
  });

  window.requestAnimationFrame(() => {
    fitAdminViewport();
  });
}

function getApi() {
  return window.WellnessAPI;
}

function clearSession() {
  SESSION_KEYS.forEach(key => localStorage.removeItem(key));
}

function logout() {
  clearSession();
  window.location.href = "login.html";
}

function openUserModePreview() {
  window.location.href = "index.html?preview=user";
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function getCurrentUserId() {
  return Number(localStorage.getItem("userId") || "0") || null;
}

function getCurrentMonthKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}

function formatMonthLabel(monthKey) {
  if (!monthKey || !monthKey.includes("-")) {
    return "este mes";
  }

  const [year, month] = monthKey.split("-");
  return `${month}/${year}`;
}

function formatNumber(value) {
  return new Intl.NumberFormat("es-MX").format(Number(value || 0));
}

function setText(element, value) {
  if (!element) return;
  element.textContent = value;
}

function formatRoleLabel(role) {
  return role === "admin" ? "Administrador" : "Usuario";
}

function renderExecutiveOverview() {
  if (adminHeroMonth) {
    setText(adminHeroMonth, formatMonthLabel(latestAnalyticsMonth || getCurrentMonthKey()));
  }

  if (adminLastUpdated) {
    setText(
      adminLastUpdated,
      new Date().toLocaleTimeString("es-MX", {
        hour: "2-digit",
        minute: "2-digit"
      })
    );
  }

  if (adminFaceCoverage && latestDashboardStats) {
    const totalFaceSamples = Number(latestDashboardStats.total_face_samples || 0);
    setText(
      adminFaceCoverage,
      `${formatNumber(totalFaceSamples)} muestras faciales`
    );
  }

  if (adminStatusBadge) {
    const hasActivity = Number(latestGeneralAnalytics?.summary?.total_sessions || 0) > 0;
    setText(adminStatusBadge, hasActivity ? "Analisis en vivo" : "En linea");
  }

  if (!latestDashboardStats || !adminHeroTitle || !adminHeroText) {
    return;
  }

  const generalSummary = latestGeneralAnalytics?.summary || null;
  if (!generalSummary || Number(generalSummary.total_sessions || 0) === 0) {
    setText(adminHeroTitle, "Centro de operacion listo para supervision");
    setText(
      adminHeroText,
      `Administra ${formatNumber(latestDashboardStats.total_users)} usuarios, ${formatNumber(latestDashboardStats.total_face_samples || 0)} muestras faciales y el catalogo activo desde una sola vista.`
    );
    return;
  }

  const topUserName = latestDashboardStats.top_user?.nombre
    ? ` Lider actual: ${latestDashboardStats.top_user.nombre}.`
    : "";
  setText(
    adminHeroTitle,
    `${formatNumber(generalSummary.participants)} usuarios movieron la plataforma en ${formatMonthLabel(latestAnalyticsMonth)}`
  );
  setText(
    adminHeroText,
    `${formatNumber(generalSummary.total_reps)} repeticiones y ${formatNumber(generalSummary.total_points)} puntos se validaron en ${formatNumber(generalSummary.active_days)} dias activos.${topUserName}`
  );
}

function showAdminMessage(message, isError = false) {
  adminMessage.innerHTML = `<div class="message-card ${isError ? "error" : ""}">${escapeHtml(message)}</div>`;
  adminMessage.classList.add("show");

  window.clearTimeout(showAdminMessage.timer);
  showAdminMessage.timer = window.setTimeout(() => {
    adminMessage.classList.remove("show");
  }, 7000);
}

function resetForm() {
  editingExerciseId = null;
  exerciseIdInput.value = "";
  codeInput.value = "squat";
  pointsInput.value = "";
  goalInput.value = String(EXERCISE_PRESETS.squat.goal);
  nameInput.value = "";
  descInput.value = "";
  imgInput.value = EXERCISE_PRESETS.squat.image;
  colorInput.value = EXERCISE_PRESETS.squat.color;
  activeInput.checked = true;
  formTitle.innerText = "Gestionar ejercicio";
  saveExerciseBtn.innerText = "Guardar ejercicio";
  cancelEditBtn.classList.add("hidden");
}

function resetRewardForm() {
  if (!hasRewardsAdmin) return;

  editingRewardId = null;
  rewardIdInput.value = "";
  rewardNameInput.value = "";
  rewardDescInput.value = "";
  rewardCostInput.value = "";
  rewardStockInput.value = "";
  rewardActiveInput.checked = true;
  rewardFormTitle.innerText = "Gestionar recompensa";
  saveRewardBtn.innerText = "Guardar recompensa";
  cancelRewardEditBtn.classList.add("hidden");
}

function applyPresetIfCreating() {
  if (editingExerciseId) return;
  const preset = EXERCISE_PRESETS[codeInput.value];
  if (!preset) return;

  imgInput.value = preset.image;
  colorInput.value = preset.color;
  goalInput.value = String(preset.goal);
}

function populateForm(exercise) {
  editingExerciseId = exercise.id;
  exerciseIdInput.value = String(exercise.id);
  codeInput.value = exercise.codigo;
  pointsInput.value = exercise.puntos_por_rep;
  goalInput.value = exercise.objetivo_reps || 10;
  nameInput.value = exercise.nombre;
  descInput.value = exercise.descripcion;
  imgInput.value = exercise.image_path || "";
  colorInput.value = exercise.color_hex || "#38bdf8";
  activeInput.checked = exercise.activo;
  formTitle.innerText = `Editando: ${exercise.nombre}`;
  saveExerciseBtn.innerText = "Actualizar ejercicio";
  cancelEditBtn.classList.remove("hidden");
}

function populateRewardForm(reward) {
  if (!hasRewardsAdmin) return;

  editingRewardId = reward.id;
  rewardIdInput.value = String(reward.id);
  rewardNameInput.value = reward.nombre || "";
  rewardDescInput.value = reward.descripcion || "";
  rewardCostInput.value = reward.costo_puntos || "";
  rewardStockInput.value = reward.stock === null || reward.stock === undefined ? "" : reward.stock;
  rewardActiveInput.checked = reward.activo;
  rewardFormTitle.innerText = `Editando: ${reward.nombre}`;
  saveRewardBtn.innerText = "Actualizar recompensa";
  cancelRewardEditBtn.classList.remove("hidden");
}

function renderExercises() {
  list.innerHTML = "";

  if (!exercises.length) {
    list.innerHTML = "<p class='empty-state'>No hay ejercicios configurados.</p>";
    return;
  }

  exercises.forEach(exercise => {
    const card = document.createElement("div");
    card.classList.add("exercise-item");
    const exerciseCode = escapeHtml(String(exercise.codigo || "").toUpperCase());
    const statusClass = exercise.activo ? "active" : "inactive";
    const statusLabel = exercise.activo ? "Activo" : "Inactivo";

    card.innerHTML = `
      <div class="exercise-top">
        <span class="exercise-badge">${exerciseCode}</span>
        <div class="exercise-top-right">
          <span class="exercise-status ${statusClass}">${statusLabel}</span>
          <div class="exercise-color" style="background:${escapeHtml(exercise.color_hex)};"></div>
        </div>
      </div>
      <img src="${escapeHtml(exercise.image_path || "/Resources/images/squat.jpg")}" alt="${escapeHtml(exercise.nombre)}">
      <h4>${escapeHtml(exercise.nombre)}</h4>
      <p>${escapeHtml(exercise.descripcion)}</p>
      <div class="exercise-meta">
        <span>${formatNumber(exercise.puntos_por_rep)} pts/rep</span>
        <span>Meta ${formatNumber(exercise.objetivo_reps)}</span>
      </div>
      <div class="exercise-actions">
        <button class="edit-btn exercise-edit-btn" data-id="${exercise.id}">Editar</button>
        <button class="delete-btn exercise-delete-btn" data-id="${exercise.id}">Eliminar</button>
      </div>
    `;

    list.appendChild(card);
  });

  list.querySelectorAll(".exercise-edit-btn").forEach(button => {
    button.addEventListener("click", () => {
      const exercise = exercises.find(item => item.id === Number(button.dataset.id));
      if (exercise) populateForm(exercise);
    });
  });

  list.querySelectorAll(".exercise-delete-btn").forEach(button => {
    button.addEventListener("click", async () => {
      const exerciseId = Number(button.dataset.id);
      await deleteExercise(exerciseId);
    });
  });

  fitAdminViewport();
}

function renderRewardsAdmin() {
  if (!hasRewardsAdmin) {
    rewards = [];
    return;
  }

  rewardsAdminList.innerHTML = "";

  if (!rewards.length) {
    rewardsAdminList.innerHTML = "<p class='empty-state'>No hay recompensas configuradas.</p>";
    fitAdminViewport();
    return;
  }

  rewards.forEach(reward => {
    const card = document.createElement("div");
    card.classList.add("reward-item");
    const statusClass = reward.activo ? "active" : "inactive";
    const statusLabel = reward.activo ? "Activa" : "Inactiva";
    const stockLabel = reward.stock === null ? "Stock ilimitado" : `Stock ${formatNumber(reward.stock)}`;

    card.innerHTML = `
      <div class="reward-top">
        <div>
          <span class="reward-badge">${formatNumber(reward.costo_puntos)} pts</span>
          <h4>${escapeHtml(reward.nombre)}</h4>
        </div>
        <div class="reward-top-right">
          <span class="reward-status ${statusClass}">${statusLabel}</span>
        </div>
      </div>
      <p>${escapeHtml(reward.descripcion)}</p>
      <div class="reward-meta">
        <span class="reward-meta-pill">${stockLabel}</span>
        <span class="reward-meta-pill">${reward.activo ? "Visible para usuarios" : "Oculta para usuarios"}</span>
      </div>
      <div class="reward-actions">
        <button class="edit-btn reward-edit-btn" data-id="${reward.id}">Editar</button>
      </div>
    `;

    rewardsAdminList.appendChild(card);
  });

  rewardsAdminList.querySelectorAll(".reward-edit-btn").forEach(button => {
    button.addEventListener("click", () => {
      const reward = rewards.find(item => item.id === Number(button.dataset.id));
      if (reward) populateRewardForm(reward);
    });
  });

  fitAdminViewport();
}

function renderUsers(users) {
  usersTableBody.innerHTML = "";

  if (!users.length) {
    usersTableBody.innerHTML = "<tr><td colspan='7'>No hay usuarios registrados.</td></tr>";
    return;
  }

  const currentUserId = getCurrentUserId();
  const adminCount = users.filter(user => user.role === "admin").length;

  users.forEach(user => {
    const row = document.createElement("tr");
    const isCurrentAdmin = user.id === currentUserId;
    const isProtectedAdmin = user.role === "admin" && adminCount <= 1;
    const canDelete = !isCurrentAdmin && !isProtectedAdmin;
    const deleteLabel = isCurrentAdmin
      ? "Sesion actual"
      : isProtectedAdmin
        ? "Ultimo admin"
        : "Eliminar";

    row.innerHTML = `
      <td>${escapeHtml(user.nombre)}</td>
      <td><span class="user-role">${escapeHtml(formatRoleLabel(user.role))}</span></td>
      <td>${formatNumber(user.points_balance)}</td>
      <td>${formatNumber(user.points_earned)}</td>
      <td>${formatNumber(user.sessions_count)}</td>
      <td>
        <div class="user-actions">
          <button
            class="delete-btn user-delete-btn"
            data-id="${user.id}"
            data-name="${escapeHtml(user.nombre)}"
            ${canDelete ? "" : "disabled"}
          >
            ${deleteLabel}
          </button>
        </div>
      </td>
    `;

    usersTableBody.appendChild(row);
  });

  document.querySelectorAll(".user-delete-btn").forEach(button => {
    if (button.disabled) return;

    button.addEventListener("click", async () => {
      const userId = Number(button.dataset.id);
      const userName = button.dataset.name || "este usuario";
      await deleteUser(userId, userName);
    });
  });

  fitAdminViewport();
}

function renderLeaderboard(items) {
  leaderboard.innerHTML = "";

  if (!items.length) {
    leaderboard.innerHTML = "<p class='empty-state'>Aun no hay datos para el ranking.</p>";
    return;
  }

  items.forEach((user, index) => {
    const card = document.createElement("div");
    card.classList.add("leaderboard-item");
    card.innerHTML = `
      <div class="leaderboard-rank">#${index + 1}</div>
      <div>
        <strong>${escapeHtml(user.nombre)}</strong>
        <p>${formatNumber(user.sessions_count)} sesiones completadas</p>
      </div>
      <div class="leaderboard-score">
        <strong>${formatNumber(user.points_earned)} pts</strong>
        <span>${formatNumber(user.points_balance)} disponibles</span>
      </div>
    `;
    leaderboard.appendChild(card);
  });

  fitAdminViewport();
}

function renderStats(stats) {
  latestDashboardStats = stats;

  setText(totalUsersElement, formatNumber(stats.total_users));
  setText(totalPointsElement, formatNumber(stats.total_points));
  setText(totalSessionsElement, formatNumber(stats.total_sessions));
  setText(
    topUserElement,
    stats.top_user
      ? `${stats.top_user.nombre} (${formatNumber(stats.top_user.points_earned)})`
      : "-"
  );

  setText(
    totalSessionsMeta,
    "Sesiones cerradas y auditables por el sistema"
  );
  setText(
    topUserMeta,
    stats.top_user
      ? `${formatNumber(stats.top_user.sessions_count)} sesiones completadas`
      : "Sin liderazgo registrado"
  );

  renderExecutiveOverview();
}

function renderSummaryPills(container, items) {
  container.innerHTML = items
    .map(item => `
      <div class="summary-pill">
        <strong>${escapeHtml(typeof item.value === "number" ? formatNumber(item.value) : item.value)}</strong>
        <span>${escapeHtml(item.label)}</span>
      </div>
    `)
    .join("");
}

function renderLegend(container, items, labelBuilder) {
  if (!items.length) {
    container.innerHTML = "";
    return;
  }

  container.innerHTML = items
    .map(item => `
      <div class="legend-item">
        <span class="legend-swatch" style="background:${escapeHtml(item.color)};"></span>
        <span>${escapeHtml(labelBuilder(item))}</span>
      </div>
    `)
    .join("");
}

function setEmptyChart(container, message) {
  container.classList.add("empty-chart");
  container.innerHTML = `<p>${escapeHtml(message)}</p>`;
}

function getNiceMax(value) {
  if (value <= 5) return 5;

  const magnitude = 10 ** Math.floor(Math.log10(value));
  const residual = value / magnitude;

  if (residual <= 1) return magnitude;
  if (residual <= 2) return 2 * magnitude;
  if (residual <= 5) return 5 * magnitude;
  return 10 * magnitude;
}

function renderStackedBarChart(container, chartTitle, labels, datasets, fullLabels) {
  const totals = labels.map((_, index) => {
    return datasets.reduce((sum, dataset) => sum + Number(dataset.values[index] || 0), 0);
  });

  if (!labels.length || !totals.some(total => total > 0)) {
    setEmptyChart(container, "No hay actividad registrada para el filtro seleccionado.");
    return;
  }

  container.classList.remove("empty-chart");

  const height = 260;
  const padding = { top: 16, right: 14, bottom: 38, left: 36 };
  const width = Math.max((container.clientWidth || 0) - 20, 320);
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  const barWidth = Math.max(6, Math.min(22, (chartWidth / labels.length) * 0.58));
  const maxValue = getNiceMax(Math.max(...totals, 1));

  let gridLines = "";
  let yLabels = "";
  const steps = 4;

  for (let step = 0; step <= steps; step += 1) {
    const currentValue = Math.round((maxValue / steps) * step);
    const y = padding.top + chartHeight - (currentValue / maxValue) * chartHeight;
    gridLines += `<line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="rgba(255,255,255,0.12)" stroke-dasharray="4 4" />`;
    yLabels += `<text x="${padding.left - 6}" y="${y + 4}" text-anchor="end" fill="rgba(255,255,255,0.75)" font-size="10">${currentValue}</text>`;
  }

  let bars = "";
  let xLabels = "";

  labels.forEach((label, index) => {
    const x = padding.left + (chartWidth / labels.length) * index + ((chartWidth / labels.length) - barWidth) / 2;
    let stackedHeight = 0;

    datasets.forEach(dataset => {
      const value = Number(dataset.values[index] || 0);
      if (value <= 0) return;

      const rectHeight = (value / maxValue) * chartHeight;
      const y = padding.top + chartHeight - stackedHeight - rectHeight;
      stackedHeight += rectHeight;

      const tooltip = `${fullLabels[index]} | ${dataset.name}: ${value} reps`;
      bars += `
        <rect
          x="${x}"
          y="${y}"
          width="${barWidth}"
          height="${rectHeight}"
          rx="8"
          fill="${escapeHtml(dataset.color)}"
          opacity="0.92"
        >
          <title>${escapeHtml(tooltip)}</title>
        </rect>
      `;
    });

    if (totals[index] > 0) {
      bars += `
        <text
          x="${x + barWidth / 2}"
          y="${padding.top + chartHeight - stackedHeight - 8}"
          text-anchor="middle"
          fill="rgba(255,255,255,0.88)"
          font-size="9"
          font-weight="700"
        >
          ${totals[index]}
        </text>
      `;
    }

    const shouldRenderLabel =
      labels.length <= 16 ||
      index % Math.ceil(labels.length / 10) === 0 ||
      index === labels.length - 1;
    xLabels += `
      <text
        x="${x + barWidth / 2}"
        y="${height - 16}"
        text-anchor="middle"
        fill="rgba(255,255,255,0.78)"
        font-size="10"
      >
        ${shouldRenderLabel ? escapeHtml(label) : ""}
      </text>
    `;
  });

  container.innerHTML = `
    <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeHtml(chartTitle)}">
      ${gridLines}
      <line x1="${padding.left}" y1="${padding.top}" x2="${padding.left}" y2="${padding.top + chartHeight}" stroke="rgba(255,255,255,0.3)" />
      <line x1="${padding.left}" y1="${padding.top + chartHeight}" x2="${width - padding.right}" y2="${padding.top + chartHeight}" stroke="rgba(255,255,255,0.3)" />
      ${yLabels}
      ${bars}
      ${xLabels}
    </svg>
  `;

  fitAdminViewport();
}

function renderGeneralAnalytics(general, monthKey) {
  const summary = general?.summary || {
    active_days: 0,
    participants: 0,
    total_sessions: 0,
    total_reps: 0,
    total_points: 0
  };

  renderSummaryPills(generalChartSummary, [
    { value: summary.active_days, label: "dias activos" },
    { value: summary.participants, label: "usuarios con actividad" },
    { value: summary.total_sessions, label: "sesiones completadas" },
    { value: summary.total_reps, label: "repeticiones" },
    { value: summary.total_points, label: "puntos generados" }
  ]);

  const daily = general?.daily_activity || [];
  const userTotals = general?.user_totals || [];
  const datasets = userTotals.map(user => ({
    name: user.nombre,
    color: user.color,
    values: daily.map(day => {
      const match = (day.users || []).find(item => item.user_id === user.user_id);
      return match ? match.total_reps : 0;
    })
  }));

  renderStackedBarChart(
    generalChart,
    `Actividad general del mes ${monthKey}`,
    daily.map(item => item.label),
    datasets,
    daily.map(item => item.date)
  );

  renderLegend(generalChartLegend, userTotals.map(user => ({
    color: user.color,
    label: `${user.nombre} (${user.total_reps} reps)`
  })), item => item.label);

  if (!daily.length) {
    generalDayDetails.innerHTML = `
      <div class="analytics-detail-card">
        <h4>Sin actividad</h4>
        <p>No hay sesiones completadas en ${escapeHtml(formatMonthLabel(monthKey))}.</p>
      </div>
    `;
    fitAdminViewport();
    return;
  }

  generalDayDetails.innerHTML = [...daily]
    .reverse()
    .map(day => `
      <div class="analytics-detail-card">
        <h4>${escapeHtml(day.label)}</h4>
        <p><strong>${formatNumber(day.total_reps)} reps</strong> en ${formatNumber(day.session_count)} sesiones</p>
        <p>Usuarios: ${escapeHtml((day.users || []).map(user => `${user.nombre} (${user.total_reps})`).join(", ") || "Sin detalle")}</p>
        <p>Ejercicios: ${escapeHtml((day.exercises || []).map(exercise => `${exercise.nombre} (${exercise.total_reps})`).join(", ") || "Sin detalle")}</p>
      </div>
    `)
    .join("");

  fitAdminViewport();
}

function renderUserAnalytics(userDetail, monthKey) {
  if (!userDetail) {
    renderSummaryPills(userChartSummary, [
      { value: 0, label: "dias activos" },
      { value: 0, label: "sesiones" },
      { value: 0, label: "repeticiones" },
      { value: 0, label: "puntos" }
    ]);
    setEmptyChart(userChart, "Selecciona un usuario para ver sus estadisticas.");
    userChartLegend.innerHTML = "";
    userExerciseBreakdown.innerHTML = `
      <div class="analytics-detail-card">
        <h4>Sin usuario</h4>
        <p>Selecciona un usuario para revisar sus ejercicios y avance mensual.</p>
      </div>
    `;
    userRecentSessions.innerHTML = "";
    fitAdminViewport();
    return;
  }

  const summary = userDetail.summary || {
    active_days: 0,
    total_sessions: 0,
    total_reps: 0,
    total_points: 0
  };

  renderSummaryPills(userChartSummary, [
    { value: summary.active_days, label: "dias activos" },
    { value: summary.total_sessions, label: "sesiones" },
    { value: summary.total_reps, label: "repeticiones" },
    { value: summary.total_points, label: "puntos" }
  ]);

  const daily = userDetail.daily_activity || [];
  const exerciseBreakdown = userDetail.exercise_breakdown || [];
  const datasets = exerciseBreakdown.map(exercise => ({
    name: exercise.nombre,
    color: exercise.color_hex,
    values: daily.map(day => {
      const match = (day.exercises || []).find(item => item.exercise_id === exercise.exercise_id);
      return match ? match.total_reps : 0;
    })
  }));

  renderStackedBarChart(
    userChart,
    `Actividad del usuario ${userDetail.user.nombre} en ${monthKey}`,
    daily.map(item => item.label),
    datasets,
    daily.map(item => item.date)
  );

  renderLegend(userChartLegend, exerciseBreakdown.map(exercise => ({
    color: exercise.color_hex,
    label: `${exercise.nombre} (${exercise.total_reps} reps)`
  })), item => item.label);

  if (!exerciseBreakdown.length) {
    userExerciseBreakdown.innerHTML = `
      <div class="analytics-detail-card">
        <h4>${escapeHtml(userDetail.user.nombre)}</h4>
        <p>No hay ejercicios completados en ${escapeHtml(formatMonthLabel(monthKey))}.</p>
      </div>
    `;
  } else {
    userExerciseBreakdown.innerHTML = exerciseBreakdown
      .map(exercise => `
        <div class="analytics-detail-card">
          <div class="detail-row">
            <span class="detail-dot" style="background:${escapeHtml(exercise.color_hex)};"></span>
            <h4>${escapeHtml(exercise.nombre)}</h4>
          </div>
          <p><strong>${formatNumber(exercise.total_reps)} reps</strong> en ${formatNumber(exercise.session_count)} sesiones</p>
          <p>${formatNumber(exercise.total_points)} puntos generados</p>
        </div>
      `)
      .join("");
  }

  const recentSessions = userDetail.recent_sessions || [];
  if (!recentSessions.length) {
    userRecentSessions.innerHTML = `
      <div class="analytics-detail-card">
        <h4>Sin sesiones recientes</h4>
        <p>No hay tickets recientes para este usuario en el mes filtrado.</p>
      </div>
    `;
    fitAdminViewport();
    return;
  }

  userRecentSessions.innerHTML = recentSessions
    .map(session => `
        <div class="analytics-detail-card">
          <div>
            <h4>${escapeHtml(session.exercise_name)}</h4>
            <p>${escapeHtml(session.started_label)}</p>
          </div>
          <div>
            <strong>${formatNumber(session.reps)} reps</strong>
            <p>${formatNumber(session.points_earned)} pts</p>
          </div>
        </div>
      `)
    .join("");

  fitAdminViewport();
}

function syncAnalyticsUserOptions(users, preferredUserId = null) {
  if (!users.length) {
    selectedAnalyticsUserId = null;
    analyticsUserSelect.disabled = true;
    analyticsUserSelect.innerHTML = "<option value=''>Sin usuarios</option>";
    return;
  }

  analyticsUserSelect.disabled = false;

  if (!selectedAnalyticsUserId || !users.some(user => user.id === selectedAnalyticsUserId)) {
    selectedAnalyticsUserId = preferredUserId && users.some(user => user.id === preferredUserId)
      ? preferredUserId
      : users[0].id;
  }

  analyticsUserSelect.innerHTML = users
    .map(user => `
      <option value="${user.id}" ${user.id === selectedAnalyticsUserId ? "selected" : ""}>
        ${escapeHtml(user.nombre)} (${escapeHtml(formatRoleLabel(user.role))})
      </option>
    `)
    .join("");
}

async function refreshAnalytics() {
  const monthKey = analyticsMonthInput.value || getCurrentMonthKey();
  analyticsMonthInput.value = monthKey;

  const baseAnalytics = await getApi().getAdminAnalytics(monthKey);
  latestGeneralAnalytics = baseAnalytics.general || null;
  latestAnalyticsMonth = baseAnalytics.month;
  const preferredUserId = baseAnalytics.general?.user_totals?.[0]?.user_id || null;
  syncAnalyticsUserOptions(baseAnalytics.users || [], preferredUserId);
  renderGeneralAnalytics(baseAnalytics.general, baseAnalytics.month);
  renderExecutiveOverview();

  if (!selectedAnalyticsUserId) {
    renderUserAnalytics(null, baseAnalytics.month);
    return;
  }

  const userAnalytics = await getApi().getAdminAnalytics(baseAnalytics.month, selectedAnalyticsUserId);
  renderUserAnalytics(userAnalytics.user_detail, userAnalytics.month);
}

async function refreshAdminData() {
  const rewardsRequest = hasRewardsAdmin
    ? getApi().getRewards(true)
    : Promise.resolve({ rewards: [] });

  const [dashboardResponse, exercisesResponse, rewardsResponse, usersResponse, leaderboardResponse] = await Promise.all([
    getApi().getAdminDashboard(),
    getApi().getExercises(true),
    rewardsRequest,
    getApi().getUsers(),
    getApi().getLeaderboard(10)
  ]);

  exercises = exercisesResponse.exercises || [];
  rewards = rewardsResponse.rewards || [];
  renderStats(dashboardResponse.stats);
  renderExercises();
  renderRewardsAdmin();
  renderUsers(usersResponse.users || []);
  renderLeaderboard(leaderboardResponse.leaderboard || []);
  await refreshAnalytics();
}

function buildPayload() {
  const payload = {
    codigo: codeInput.value,
    nombre: nameInput.value.trim(),
    descripcion: descInput.value.trim(),
    image_path: imgInput.value.trim(),
    color_hex: colorInput.value,
    puntos_por_rep: Number(pointsInput.value),
    objetivo_reps: Number(goalInput.value),
    duracion_segundos: 20,
    activo: activeInput.checked
  };

  if (!payload.nombre || !payload.descripcion || !payload.image_path) {
    throw new Error("Completa todos los campos del ejercicio.");
  }

  if (!payload.puntos_por_rep || !payload.objetivo_reps) {
    throw new Error("Define puntos y objetivo sugerido validos.");
  }

  return payload;
}

function buildRewardPayload() {
  if (!hasRewardsAdmin) {
    throw new Error("La seccion de recompensas no esta disponible en esta vista.");
  }

  const stockValue = rewardStockInput.value.trim();
  const payload = {
    nombre: rewardNameInput.value.trim(),
    descripcion: rewardDescInput.value.trim(),
    costo_puntos: Number(rewardCostInput.value),
    stock: stockValue === "" ? null : Number(stockValue),
    activo: rewardActiveInput.checked
  };

  if (!payload.nombre || !payload.descripcion) {
    throw new Error("Completa todos los campos de la recompensa.");
  }

  if (!payload.costo_puntos) {
    throw new Error("Define un costo en puntos valido.");
  }

  if (payload.stock !== null && (!Number.isFinite(payload.stock) || payload.stock < 0)) {
    throw new Error("El stock debe ser un numero valido o quedar vacio para ilimitado.");
  }

  return payload;
}

async function saveExercise() {
  try {
    const payload = buildPayload();

    if (editingExerciseId) {
      await getApi().updateExercise(editingExerciseId, payload);
      showAdminMessage("Ejercicio actualizado correctamente.");
    } else {
      await getApi().createExercise(payload);
      showAdminMessage("Ejercicio creado correctamente.");
    }

    resetForm();
    await refreshAdminData();
  } catch (error) {
    showAdminMessage(error.message, true);
  }
}

async function saveReward() {
  if (!hasRewardsAdmin) return;

  try {
    const payload = buildRewardPayload();

    if (editingRewardId) {
      await getApi().updateReward(editingRewardId, payload);
      showAdminMessage("Recompensa actualizada correctamente.");
    } else {
      await getApi().createReward(payload);
      showAdminMessage("Recompensa creada correctamente.");
    }

    resetRewardForm();
    await refreshAdminData();
  } catch (error) {
    showAdminMessage(error.message, true);
  }
}

async function deleteExercise(exerciseId) {
  if (!window.confirm("Deseas eliminar este ejercicio?")) {
    return;
  }

  try {
    await getApi().deleteExercise(exerciseId);
    showAdminMessage("Ejercicio eliminado correctamente.");
    if (editingExerciseId === exerciseId) {
      resetForm();
    }
    await refreshAdminData();
  } catch (error) {
    showAdminMessage(error.message, true);
  }
}

async function deleteUser(userId, userName) {
  if (!window.confirm(`Deseas eliminar a ${userName}? Tambien se borraran sus rostros, sesiones y puntos.`)) {
    return;
  }

  try {
    await getApi().deleteUser(userId);
    if (selectedAnalyticsUserId === userId) {
      selectedAnalyticsUserId = null;
    }
    showAdminMessage("Usuario eliminado correctamente.");
    await refreshAdminData();
  } catch (error) {
    showAdminMessage(error.message, true);
  }
}

if (saveExerciseBtn) {
  saveExerciseBtn.addEventListener("click", saveExercise);
}
if (cancelEditBtn) {
  cancelEditBtn.addEventListener("click", resetForm);
}
if (saveRewardBtn) {
  saveRewardBtn.addEventListener("click", saveReward);
}
if (cancelRewardEditBtn) {
  cancelRewardEditBtn.addEventListener("click", resetRewardForm);
}
if (logoutBtn) {
  logoutBtn.addEventListener("click", logout);
}
if (openUserModeBtn) {
  openUserModeBtn.addEventListener("click", openUserModePreview);
}
if (codeInput) {
  codeInput.addEventListener("change", applyPresetIfCreating);
}
if (analyticsMonthInput) {
  analyticsMonthInput.addEventListener("change", async () => {
    try {
      await refreshAnalytics();
    } catch (error) {
      showAdminMessage(error.message, true);
    }
  });
}
if (analyticsUserSelect) {
  analyticsUserSelect.addEventListener("change", async () => {
    selectedAnalyticsUserId = Number(analyticsUserSelect.value || "0") || null;
    try {
      await refreshAnalytics();
    } catch (error) {
      showAdminMessage(error.message, true);
    }
  });
}
workspaceTabs.forEach(button => {
  button.addEventListener("click", () => {
    setActiveAdminTab(button.dataset.tab);
  });
});
window.addEventListener("resize", fitAdminViewport);
window.addEventListener("orientationchange", fitAdminViewport);

(async function init() {
  try {
    setActiveAdminTab(activeAdminTab);
    resetForm();
    resetRewardForm();
    if (analyticsMonthInput) {
      analyticsMonthInput.value = getCurrentMonthKey();
    }
    await refreshAdminData();
    fitAdminViewport();
  } catch (error) {
    showAdminMessage(error.message, true);
  }
})();
