import math
import os
from datetime import datetime, timezone
from typing import Dict, Optional
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import desc, func, inspect, text
from sqlalchemy.orm import Session, joinedload

from .database import Base, SessionLocal, engine, get_db
from .exercise_logic import SUPPORTED_EXERCISES, default_session_state, process_landmarks
from .models import CanjeRecompensa, Ejercicio, Recompensa, SesionEntrenamiento, User, UserFace
from .schemas import (
    ExercisePayload,
    FaceLoginRequest,
    FaceRegisterRequest,
    RewardPayload,
    RewardRedemptionRequest,
    SessionFinishRequest,
    SessionFrameRequest,
    SessionStartRequest,
)

app = FastAPI(title="Ergonomic Wellness API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FACE_MATCH_THRESHOLD = float(os.getenv("FACE_MATCH_THRESHOLD", "0.46"))
FACE_MATCH_AVERAGE_THRESHOLD = float(os.getenv("FACE_MATCH_AVERAGE_THRESHOLD", "0.43"))
FACE_MATCH_MARGIN = float(os.getenv("FACE_MATCH_MARGIN", "0.05"))
FACE_MIN_CONFIRMATIONS = max(1, int(os.getenv("FACE_MIN_CONFIRMATIONS", "3")))
try:
    APP_TIMEZONE = ZoneInfo("America/Mexico_City")
except ZoneInfoNotFoundError:
    APP_TIMEZONE = timezone.utc
session_states: Dict[int, Dict] = {}

DEFAULT_EXERCISES = [
    {
        "codigo": "squat",
        "nombre": "Sentadillas",
        "descripcion": "Baja la cadera, mantén el pecho erguido y vuelve a subir.",
        "image_path": "/Resources/images/squat.jpg",
        "color_hex": "#38bdf8",
        "puntos_por_rep": 10,
        "objetivo_reps": 12,
        "duracion_segundos": 20,
    },
    {
        "codigo": "arms",
        "nombre": "Elevación de brazos",
        "descripcion": "Eleva ambos brazos por encima de los hombros y regresa.",
        "image_path": "/Resources/images/arms.jpg",
        "color_hex": "#22c55e",
        "puntos_por_rep": 8,
        "objetivo_reps": 15,
        "duracion_segundos": 20,
    },
    {
        "codigo": "knees",
        "nombre": "Rodillas al pecho",
        "descripcion": "Alterna rodillas arriba hasta la altura de la cadera.",
        "image_path": "/Resources/images/knees.jpg",
        "color_hex": "#f59e0b",
        "puntos_por_rep": 6,
        "objetivo_reps": 18,
        "duracion_segundos": 20,
    },
    {
        "codigo": "side",
        "nombre": "Flexión lateral",
        "descripcion": "Inclina el torso hacia los costados manteniendo el control.",
        "image_path": "/Resources/images/side.jpg",
        "color_hex": "#f97316",
        "puntos_por_rep": 5,
        "objetivo_reps": 10,
        "duracion_segundos": 20,
    },
]

DEFAULT_REWARDS = [
    {
        "nombre": "Botella reutilizable",
        "descripcion": "Canjea tus puntos por una botella corporativa.",
        "costo_puntos": 80,
        "stock": 20,
    },
    {
        "nombre": "Vale de cafetería",
        "descripcion": "Cupón para snack o bebida saludable.",
        "costo_puntos": 120,
        "stock": 15,
    },
    {
        "nombre": "Día wellness",
        "descripcion": "Beneficio interno para una pausa extendida de bienestar.",
        "costo_puntos": 200,
        "stock": 10,
    },
]

USER_ANALYTICS_COLORS = [
    "#38bdf8",
    "#22c55e",
    "#f59e0b",
    "#f97316",
    "#e879f9",
    "#a78bfa",
    "#14b8a6",
    "#fb7185",
    "#facc15",
    "#60a5fa",
]


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(bind=engine)
    ensure_schema_updates()
    with SessionLocal() as db:
        seed_defaults(db)


@app.get("/")
def home():
    return {"message": "API funcionando", "supported_exercises": SUPPORTED_EXERCISES}


@app.post("/auth/register-face")
def register_face(payload: FaceRegisterRequest, db: Session = Depends(get_db)):
    role = normalize_role(payload.role)
    nombre = payload.nombre.strip()
    face_samples = extract_face_embeddings(payload.embedding, payload.embeddings)
    existing = db.query(User).filter(func.lower(User.nombre) == nombre.lower()).first()
    if existing:
        raise HTTPException(status_code=400, detail="Ya existe un usuario con ese nombre.")

    user = User(nombre=nombre, role=role)
    db.add(user)
    db.flush()

    for sample in face_samples:
        db.add(
            UserFace(
                user_id=user.id,
                image_path=payload.image_path,
                embedding=sample,
            )
        )
    db.commit()
    db.refresh(user)

    return {
        "message": "Usuario registrado correctamente.",
        "face_samples": len(face_samples),
        "user": serialize_user(user, db),
    }


@app.post("/auth/login-face")
def login_face(payload: FaceLoginRequest, db: Session = Depends(get_db)):
    login_samples = extract_face_embeddings(payload.embedding, payload.embeddings)
    faces = db.query(UserFace).options(joinedload(UserFace.usuario)).all()
    if not faces:
        return {"validado": False, "message": "Aún no hay usuarios registrados."}

    faces_by_user: Dict[int, Dict] = {}
    for face in faces:
        if not face.usuario:
            continue

        bucket = faces_by_user.setdefault(
            face.user_id,
            {
                "user": face.usuario,
                "embeddings": [],
            },
        )
        bucket["embeddings"].append(face.embedding)

    candidates = []
    for user_id, item in faces_by_user.items():
        per_sample_distances = []
        for sample in login_samples:
            best_for_sample = min(
                face_distance(sample, stored_sample)
                for stored_sample in item["embeddings"]
            )
            per_sample_distances.append(best_for_sample)

        average_distance = sum(per_sample_distances) / len(per_sample_distances)
        candidates.append(
            {
                "user_id": user_id,
                "user": item["user"],
                "average_distance": average_distance,
                "best_distance": min(per_sample_distances),
                "confirmed_samples": sum(
                    1 for distance in per_sample_distances if distance <= FACE_MATCH_THRESHOLD
                ),
                "stored_face_samples": len(item["embeddings"]),
            }
        )

    candidates.sort(key=lambda item: (item["average_distance"], item["best_distance"]))
    best_candidate = candidates[0] if candidates else None
    second_candidate = candidates[1] if len(candidates) > 1 else None
    required_confirmations = min(FACE_MIN_CONFIRMATIONS, len(login_samples))
    ambiguous_match = (
        best_candidate is not None
        and second_candidate is not None
        and (second_candidate["average_distance"] - best_candidate["average_distance"]) < FACE_MATCH_MARGIN
    )

    if (
        best_candidate is None
        or best_candidate["confirmed_samples"] < required_confirmations
        or best_candidate["average_distance"] > FACE_MATCH_AVERAGE_THRESHOLD
        or ambiguous_match
    ):
        return {"validado": False, "message": "Usuario no reconocido."}

    return {
        "validado": True,
        "message": f"Bienvenido {best_candidate['user'].nombre}.",
        "match_distance": round(best_candidate["average_distance"], 4),
        "matched_samples": best_candidate["confirmed_samples"],
        "stored_face_samples": best_candidate["stored_face_samples"],
        "user": serialize_user(best_candidate["user"], db),
    }


@app.get("/users")
def get_users(db: Session = Depends(get_db)):
    users = db.query(User).order_by(User.created_at.asc()).all()
    return {"users": [serialize_user(user, db) for user in users]}


@app.get("/users/{user_id}")
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado.")
    return {"user": serialize_user(user, db)}


@app.delete("/users/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado.")

    if user.role == "admin":
        admin_count = db.query(func.count(User.id)).filter(User.role == "admin").scalar() or 0
        if int(admin_count) <= 1:
            raise HTTPException(
                status_code=400,
                detail="No puedes eliminar al ultimo administrador registrado.",
            )

    deleted_user = serialize_basic_user(user)
    for session in user.sesiones:
        session_states.pop(session.id, None)

    db.delete(user)
    db.commit()

    return {"message": "Usuario eliminado correctamente.", "user": deleted_user}


@app.get("/users/{user_id}/history")
def get_user_history(
    user_id: int,
    month: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado.")

    month_key = resolve_month_key(month)
    sessions = (
        db.query(SesionEntrenamiento)
        .filter(
            SesionEntrenamiento.user_id == user_id,
            SesionEntrenamiento.status == "completed",
        )
        .order_by(SesionEntrenamiento.started_at.desc())
        .all()
    )

    days_map: Dict[str, Dict] = {}
    total_sessions = 0
    total_points = 0
    total_reps = 0

    for session in sessions:
        started_local = to_local_datetime(session.started_at)
        if started_local.strftime("%Y-%m") != month_key:
            continue

        date_key = started_local.date().isoformat()
        bucket = days_map.setdefault(
            date_key,
            {
                "date": date_key,
                "total_points": 0,
                "total_reps": 0,
                "sessions": [],
                "exercise_codes": [],
            },
        )

        item = serialize_history_session(session)
        bucket["sessions"].append(item)
        bucket["total_points"] += item["points_earned"]
        bucket["total_reps"] += item["reps"]
        if item["exercise_code"] not in bucket["exercise_codes"]:
            bucket["exercise_codes"].append(item["exercise_code"])

        total_sessions += 1
        total_points += item["points_earned"]
        total_reps += item["reps"]

    active_exercises = db.query(Ejercicio).filter(Ejercicio.activo.is_(True)).all()
    return {
        "month": month_key,
        "summary": {
            "active_days": len(days_map),
            "total_sessions": total_sessions,
            "total_points": total_points,
            "total_reps": total_reps,
        },
        "days": [days_map[key] for key in sorted(days_map.keys())],
        "legend": [
            {
                "codigo": exercise.codigo,
                "nombre": exercise.nombre,
                "color_hex": exercise.color_hex,
            }
            for exercise in active_exercises
        ],
    }


@app.get("/leaderboard")
def leaderboard(limit: int = Query(default=10, ge=1, le=50), db: Session = Depends(get_db)):
    users = (
        db.query(User)
        .order_by(desc(User.points_earned), desc(User.points_balance), User.nombre.asc())
        .limit(limit)
        .all()
    )
    return {"leaderboard": [serialize_user(user, db) for user in users]}


@app.get("/admin/dashboard")
def admin_dashboard(db: Session = Depends(get_db)):
    total_users = db.query(User).count()
    total_points = db.query(func.coalesce(func.sum(User.points_earned), 0)).scalar() or 0
    total_face_samples = db.query(func.count(UserFace.id)).scalar() or 0
    total_sessions = (
        db.query(func.count(SesionEntrenamiento.id))
        .filter(SesionEntrenamiento.status == "completed")
        .scalar()
        or 0
    )
    face_sample_totals = (
        db.query(UserFace.user_id, func.count(UserFace.id))
        .group_by(UserFace.user_id)
        .all()
    )
    multi_sample_users = sum(1 for _, sample_count in face_sample_totals if int(sample_count or 0) >= 3)
    top_user = (
        db.query(User)
        .order_by(desc(User.points_earned), desc(User.points_balance), User.nombre.asc())
        .first()
    )
    return {
        "stats": {
            "total_users": total_users,
            "total_points": int(total_points),
            "total_face_samples": int(total_face_samples),
            "multi_sample_users": int(multi_sample_users),
            "total_sessions": int(total_sessions),
            "top_user": serialize_user(top_user, db) if top_user else None,
        }
    }


@app.get("/admin/analytics")
def admin_analytics(
    month: Optional[str] = Query(default=None),
    user_id: Optional[int] = Query(default=None, ge=1),
    db: Session = Depends(get_db),
):
    month_key = resolve_month_key(month)
    selected_user = None

    if user_id is not None:
        selected_user = db.get(User, user_id)
        if not selected_user:
            raise HTTPException(status_code=404, detail="Usuario no encontrado.")

    sessions = (
        db.query(SesionEntrenamiento)
        .options(
            joinedload(SesionEntrenamiento.usuario),
            joinedload(SesionEntrenamiento.ejercicio),
        )
        .filter(SesionEntrenamiento.status == "completed")
        .order_by(SesionEntrenamiento.started_at.asc())
        .all()
    )
    analytics = build_admin_analytics(sessions, month_key, selected_user)
    users = db.query(User).order_by(User.nombre.asc()).all()

    return {
        "month": month_key,
        "users": [serialize_basic_user(user) for user in users],
        "general": analytics["general"],
        "user_detail": analytics["user_detail"],
    }


@app.get("/exercises")
def get_exercises(
    include_inactive: bool = Query(default=False),
    db: Session = Depends(get_db),
):
    query = db.query(Ejercicio)
    if not include_inactive:
        query = query.filter(Ejercicio.activo.is_(True))
    exercises = query.order_by(Ejercicio.nombre.asc()).all()
    return {"exercises": [serialize_exercise(item) for item in exercises]}


@app.post("/exercises")
def create_exercise(payload: ExercisePayload, db: Session = Depends(get_db)):
    codigo = normalize_exercise_code(payload.codigo)
    existing = db.query(Ejercicio).filter(Ejercicio.codigo == codigo).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail="Ese tipo de ejercicio ya existe. Usa editar para modificarlo.",
        )

    exercise = Ejercicio(
        codigo=codigo,
        nombre=payload.nombre.strip(),
        descripcion=payload.descripcion.strip(),
        image_path=payload.image_path,
        color_hex=normalize_color(payload.color_hex),
        puntos_por_rep=payload.puntos_por_rep,
        objetivo_reps=payload.objetivo_reps,
        duracion_segundos=payload.duracion_segundos,
        activo=payload.activo,
    )
    db.add(exercise)
    db.commit()
    db.refresh(exercise)
    return {"message": "Ejercicio creado correctamente.", "exercise": serialize_exercise(exercise)}


@app.put("/exercises/{exercise_id}")
def update_exercise(exercise_id: int, payload: ExercisePayload, db: Session = Depends(get_db)):
    exercise = db.get(Ejercicio, exercise_id)
    if not exercise:
        raise HTTPException(status_code=404, detail="Ejercicio no encontrado.")

    codigo = normalize_exercise_code(payload.codigo)
    duplicate = (
        db.query(Ejercicio)
        .filter(Ejercicio.codigo == codigo, Ejercicio.id != exercise_id)
        .first()
    )
    if duplicate:
        raise HTTPException(status_code=400, detail="Ese código ya está en uso.")

    exercise.codigo = codigo
    exercise.nombre = payload.nombre.strip()
    exercise.descripcion = payload.descripcion.strip()
    exercise.image_path = payload.image_path
    exercise.color_hex = normalize_color(payload.color_hex)
    exercise.puntos_por_rep = payload.puntos_por_rep
    exercise.objetivo_reps = payload.objetivo_reps
    exercise.duracion_segundos = payload.duracion_segundos
    exercise.activo = payload.activo

    db.commit()
    db.refresh(exercise)
    return {"message": "Ejercicio actualizado correctamente.", "exercise": serialize_exercise(exercise)}


@app.delete("/exercises/{exercise_id}")
def delete_exercise(exercise_id: int, db: Session = Depends(get_db)):
    exercise = db.get(Ejercicio, exercise_id)
    if not exercise:
        raise HTTPException(status_code=404, detail="Ejercicio no encontrado.")

    db.delete(exercise)
    db.commit()
    return {"message": "Ejercicio eliminado correctamente."}


@app.get("/rewards")
def get_rewards(
    include_inactive: bool = Query(default=False),
    db: Session = Depends(get_db),
):
    query = db.query(Recompensa)
    if not include_inactive:
        query = query.filter(Recompensa.activo.is_(True))
    rewards = query.order_by(Recompensa.costo_puntos.asc(), Recompensa.nombre.asc()).all()
    return {"rewards": [serialize_reward(item) for item in rewards]}


@app.post("/rewards")
def create_reward(payload: RewardPayload, db: Session = Depends(get_db)):
    nombre = payload.nombre.strip()
    existing = db.query(Recompensa).filter(func.lower(Recompensa.nombre) == nombre.lower()).first()
    if existing:
        raise HTTPException(status_code=400, detail="Ya existe una recompensa con ese nombre.")

    reward = Recompensa(
        nombre=nombre,
        descripcion=payload.descripcion.strip(),
        costo_puntos=payload.costo_puntos,
        stock=payload.stock,
        activo=payload.activo,
    )
    db.add(reward)
    db.commit()
    db.refresh(reward)
    return {"message": "Recompensa creada correctamente.", "reward": serialize_reward(reward)}


@app.put("/rewards/{reward_id}")
def update_reward(reward_id: int, payload: RewardPayload, db: Session = Depends(get_db)):
    reward = db.get(Recompensa, reward_id)
    if not reward:
        raise HTTPException(status_code=404, detail="Recompensa no encontrada.")

    nombre = payload.nombre.strip()
    duplicate = (
        db.query(Recompensa)
        .filter(func.lower(Recompensa.nombre) == nombre.lower(), Recompensa.id != reward_id)
        .first()
    )
    if duplicate:
        raise HTTPException(status_code=400, detail="Ya existe otra recompensa con ese nombre.")

    reward.nombre = nombre
    reward.descripcion = payload.descripcion.strip()
    reward.costo_puntos = payload.costo_puntos
    reward.stock = payload.stock
    reward.activo = payload.activo

    db.commit()
    db.refresh(reward)
    return {"message": "Recompensa actualizada correctamente.", "reward": serialize_reward(reward)}


@app.post("/rewards/redeem")
def redeem_reward(payload: RewardRedemptionRequest, db: Session = Depends(get_db)):
    user = db.get(User, payload.user_id)
    reward = db.get(Recompensa, payload.reward_id)
    if not user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado.")
    if not reward or not reward.activo:
        raise HTTPException(status_code=404, detail="Recompensa no encontrada.")
    if user.points_balance < reward.costo_puntos:
        raise HTTPException(status_code=400, detail="No tienes puntos suficientes para canjear.")
    if reward.stock is not None and reward.stock <= 0:
        raise HTTPException(status_code=400, detail="La recompensa ya no tiene stock disponible.")

    user.points_balance -= reward.costo_puntos
    user.points_redeemed += reward.costo_puntos
    if reward.stock is not None:
        reward.stock -= 1

    redemption = CanjeRecompensa(
        user_id=user.id,
        recompensa_id=reward.id,
        puntos_canjeados=reward.costo_puntos,
    )
    db.add(redemption)
    db.commit()
    db.refresh(user)
    db.refresh(reward)

    return {
        "message": "Recompensa canjeada correctamente.",
        "user": serialize_user(user, db),
        "reward": serialize_reward(reward),
        "redemption": {
            "reward_name": reward.nombre,
            "points_spent": reward.costo_puntos,
            "created_at": redemption.created_at.isoformat() if redemption.created_at else now_iso(),
        },
    }


@app.post("/sessions/start")
def start_session(payload: SessionStartRequest, db: Session = Depends(get_db)):
    user = db.get(User, payload.user_id)
    exercise = db.get(Ejercicio, payload.exercise_id)
    if not user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado.")
    if not exercise or not exercise.activo:
        raise HTTPException(status_code=404, detail="Ejercicio no disponible.")

    session = SesionEntrenamiento(
        user_id=user.id,
        ejercicio_id=exercise.id,
        status="started",
    )
    db.add(session)
    db.commit()
    db.refresh(session)

    session_states[session.id] = default_session_state(exercise.codigo)
    return {"session": serialize_session(session)}


@app.post("/sessions/{session_id}/frame")
def process_session_frame(
    session_id: int,
    payload: SessionFrameRequest,
    db: Session = Depends(get_db),
):
    session = db.get(SesionEntrenamiento, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Sesión no encontrada.")
    if session.status != "started":
        raise HTTPException(status_code=400, detail="La sesión ya no está activa.")

    if len(payload.landmarks) < 29:
        current_state = session_states.get(session_id, default_session_state(session.ejercicio.codigo))
        return {
            "reps": current_state.get("rep_count", 0),
            "position": current_state.get("current_state", "READY"),
            "metric": 0,
            "metric_label": "metric",
            "feedback": "No se detectó el cuerpo completo.",
            "rep_completed": False,
        }

    current_state = session_states.get(session_id) or default_session_state(session.ejercicio.codigo)
    result = process_landmarks(session.ejercicio.codigo, payload.landmarks, current_state)
    session_states[session_id] = result["state"]

    return {
        "reps": result["reps"],
        "position": result["position"],
        "metric": result["metric"],
        "metric_label": result["metric_label"],
        "feedback": result["feedback"],
        "rep_completed": result["rep_completed"],
    }


@app.post("/sessions/{session_id}/complete")
def complete_session(
    session_id: int,
    payload: SessionFinishRequest,
    db: Session = Depends(get_db),
):
    session = db.get(SesionEntrenamiento, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Sesión no encontrada.")
    if session.status == "completed":
        return {
            "message": "La sesión ya estaba cerrada.",
            "session": serialize_session(session),
            "user": serialize_user(session.usuario, db),
            "ticket": build_ticket(session, session.usuario, session.ejercicio),
        }

    runtime_state = session_states.pop(session_id, default_session_state(session.ejercicio.codigo))
    total_reps = int(runtime_state.get("rep_count", 0))
    earned_points = total_reps * session.ejercicio.puntos_por_rep

    session.total_reps = total_reps
    session.points_earned = earned_points
    session.duracion_segundos = payload.duracion_segundos or calculate_duration(session.started_at)
    session.ended_at = datetime.now(timezone.utc)
    session.status = "completed"

    session.usuario.points_balance += earned_points
    session.usuario.points_earned += earned_points

    db.commit()
    db.refresh(session)
    db.refresh(session.usuario)

    return {
        "message": "Sesión cerrada correctamente.",
        "session": serialize_session(session),
        "user": serialize_user(session.usuario, db),
        "ticket": build_ticket(session, session.usuario, session.ejercicio),
    }


def ensure_schema_updates() -> None:
    inspector = inspect(engine)
    if "ejercicios" not in inspector.get_table_names():
        return

    columns = {column["name"] for column in inspector.get_columns("ejercicios")}
    statements = []

    if "color_hex" not in columns:
        statements.append("ALTER TABLE ejercicios ADD COLUMN color_hex VARCHAR(20) DEFAULT '#38bdf8'")
    if "objetivo_reps" not in columns:
        statements.append("ALTER TABLE ejercicios ADD COLUMN objetivo_reps INTEGER DEFAULT 10")

    if not statements:
        return

    with engine.begin() as connection:
        for statement in statements:
            connection.execute(text(statement))


def seed_defaults(db: Session) -> None:
    legacy_paths = {"assets/squat.jpg", "assets/arms.jpg", "assets/knees.jpg", "assets/side.jpg"}

    for exercise_data in DEFAULT_EXERCISES:
        exercise = db.query(Ejercicio).filter(Ejercicio.codigo == exercise_data["codigo"]).first()
        if not exercise:
            db.add(Ejercicio(**exercise_data, activo=True))
            continue

        if not exercise.image_path or exercise.image_path in legacy_paths:
            exercise.image_path = exercise_data["image_path"]
        if not exercise.color_hex or exercise.color_hex == "#38bdf8":
            exercise.color_hex = exercise_data["color_hex"]
        if not exercise.objetivo_reps or exercise.objetivo_reps == 10:
            exercise.objetivo_reps = exercise_data["objetivo_reps"]
        if not exercise.duracion_segundos:
            exercise.duracion_segundos = exercise_data["duracion_segundos"]

    for reward_data in DEFAULT_REWARDS:
        reward = db.query(Recompensa).filter(Recompensa.nombre == reward_data["nombre"]).first()
        if reward:
            continue
        db.add(Recompensa(**reward_data, activo=True))

    db.commit()


def normalize_role(role: str) -> str:
    normalized = (role or "user").strip().lower()
    if normalized not in {"admin", "user"}:
        raise HTTPException(status_code=400, detail="Rol inválido. Usa admin o user.")
    return normalized


def normalize_exercise_code(code: str) -> str:
    normalized = (code or "").strip().lower()
    if normalized not in SUPPORTED_EXERCISES:
        raise HTTPException(
            status_code=400,
            detail=f"Código inválido. Usa uno de: {', '.join(SUPPORTED_EXERCISES.keys())}.",
        )
    return normalized


def normalize_color(color: str) -> str:
    normalized = (color or "").strip()
    if not normalized:
        raise HTTPException(status_code=400, detail="Debes indicar un color para el ejercicio.")
    if not normalized.startswith("#"):
        normalized = f"#{normalized}"
    return normalized


def build_admin_analytics(sessions, month_key: str, selected_user: Optional[User]) -> Dict:
    general_days: Dict[str, Dict] = {}
    general_users: Dict[int, Dict] = {}
    general_exercises: Dict[int, Dict] = {}
    user_days: Dict[str, Dict] = {}
    user_exercises: Dict[int, Dict] = {}
    user_recent_sessions = []

    total_reps = 0
    total_points = 0
    total_sessions = 0

    user_total_reps = 0
    user_total_points = 0
    user_total_sessions = 0

    for session in sessions:
        started_local = to_local_datetime(session.started_at)
        if started_local.strftime("%Y-%m") != month_key:
            continue
        if not session.usuario or not session.ejercicio:
            continue

        date_key = started_local.date().isoformat()
        day_label = started_local.strftime("%d/%m")
        reps = int(session.total_reps or 0)
        points = int(session.points_earned or 0)
        user = session.usuario
        exercise = session.ejercicio

        day_bucket = general_days.setdefault(
            date_key,
            {
                "date": date_key,
                "label": day_label,
                "total_reps": 0,
                "total_points": 0,
                "session_count": 0,
                "users_map": {},
                "exercises_map": {},
            },
        )
        day_bucket["total_reps"] += reps
        day_bucket["total_points"] += points
        day_bucket["session_count"] += 1

        day_user = day_bucket["users_map"].setdefault(
            user.id,
            {
                "user_id": user.id,
                "nombre": user.nombre,
                "color": build_user_chart_color(user),
                "total_reps": 0,
                "total_points": 0,
                "session_count": 0,
            },
        )
        day_user["total_reps"] += reps
        day_user["total_points"] += points
        day_user["session_count"] += 1

        day_exercise = day_bucket["exercises_map"].setdefault(
            exercise.id,
            {
                "exercise_id": exercise.id,
                "codigo": exercise.codigo,
                "nombre": exercise.nombre,
                "color_hex": exercise.color_hex,
                "total_reps": 0,
                "total_points": 0,
                "session_count": 0,
            },
        )
        day_exercise["total_reps"] += reps
        day_exercise["total_points"] += points
        day_exercise["session_count"] += 1

        total_user = general_users.setdefault(
            user.id,
            {
                "user_id": user.id,
                "nombre": user.nombre,
                "color": build_user_chart_color(user),
                "total_reps": 0,
                "total_points": 0,
                "session_count": 0,
            },
        )
        total_user["total_reps"] += reps
        total_user["total_points"] += points
        total_user["session_count"] += 1

        total_exercise = general_exercises.setdefault(
            exercise.id,
            {
                "exercise_id": exercise.id,
                "codigo": exercise.codigo,
                "nombre": exercise.nombre,
                "color_hex": exercise.color_hex,
                "total_reps": 0,
                "total_points": 0,
                "session_count": 0,
            },
        )
        total_exercise["total_reps"] += reps
        total_exercise["total_points"] += points
        total_exercise["session_count"] += 1

        total_reps += reps
        total_points += points
        total_sessions += 1

        if selected_user and user.id == selected_user.id:
            user_total_reps += reps
            user_total_points += points
            user_total_sessions += 1

            user_day = user_days.setdefault(
                date_key,
                {
                    "date": date_key,
                    "label": day_label,
                    "total_reps": 0,
                    "total_points": 0,
                    "session_count": 0,
                    "exercises_map": {},
                },
            )
            user_day["total_reps"] += reps
            user_day["total_points"] += points
            user_day["session_count"] += 1

            user_day_exercise = user_day["exercises_map"].setdefault(
                exercise.id,
                {
                    "exercise_id": exercise.id,
                    "codigo": exercise.codigo,
                    "nombre": exercise.nombre,
                    "color_hex": exercise.color_hex,
                    "total_reps": 0,
                    "total_points": 0,
                    "session_count": 0,
                },
            )
            user_day_exercise["total_reps"] += reps
            user_day_exercise["total_points"] += points
            user_day_exercise["session_count"] += 1

            user_exercise = user_exercises.setdefault(
                exercise.id,
                {
                    "exercise_id": exercise.id,
                    "codigo": exercise.codigo,
                    "nombre": exercise.nombre,
                    "color_hex": exercise.color_hex,
                    "total_reps": 0,
                    "total_points": 0,
                    "session_count": 0,
                },
            )
            user_exercise["total_reps"] += reps
            user_exercise["total_points"] += points
            user_exercise["session_count"] += 1
            user_recent_sessions.append(serialize_history_session(session))

    general_daily_activity = []
    for date_key in sorted(general_days.keys()):
        bucket = general_days[date_key]
        users = sort_totals(bucket.pop("users_map").values())
        exercises = sort_totals(bucket.pop("exercises_map").values())
        general_daily_activity.append(
            {
                **bucket,
                "participants": len(users),
                "users": users,
                "exercises": exercises,
            }
        )

    user_detail = None
    if selected_user is not None:
        user_daily_activity = []
        for date_key in sorted(user_days.keys()):
            bucket = user_days[date_key]
            exercises = sort_totals(bucket.pop("exercises_map").values())
            user_daily_activity.append({**bucket, "exercises": exercises})

        user_recent_sessions.sort(key=lambda item: item["started_at"], reverse=True)
        user_detail = {
            "user": serialize_basic_user(selected_user),
            "summary": {
                "active_days": len(user_days),
                "total_sessions": user_total_sessions,
                "total_points": user_total_points,
                "total_reps": user_total_reps,
            },
            "daily_activity": user_daily_activity,
            "exercise_breakdown": sort_totals(user_exercises.values()),
            "recent_sessions": user_recent_sessions[:8],
        }

    return {
        "general": {
            "summary": {
                "active_days": len(general_daily_activity),
                "total_sessions": total_sessions,
                "total_points": total_points,
                "total_reps": total_reps,
                "participants": len(general_users),
            },
            "daily_activity": general_daily_activity,
            "user_totals": sort_totals(general_users.values()),
            "exercise_totals": sort_totals(general_exercises.values()),
        },
        "user_detail": user_detail,
    }


def resolve_month_key(month: Optional[str]) -> str:
    if not month:
        return datetime.now(APP_TIMEZONE).strftime("%Y-%m")
    try:
        return datetime.strptime(month, "%Y-%m").strftime("%Y-%m")
    except ValueError as error:
        raise HTTPException(status_code=400, detail="El mes debe tener formato YYYY-MM.") from error


def to_local_datetime(value: Optional[datetime]) -> datetime:
    if value is None:
        return datetime.now(APP_TIMEZONE)
    reference = value
    if reference.tzinfo is None:
        reference = reference.replace(tzinfo=timezone.utc)
    return reference.astimezone(APP_TIMEZONE)


def build_user_chart_color(user: User) -> str:
    palette_index = (user.id + len(user.nombre or "")) % len(USER_ANALYTICS_COLORS)
    return USER_ANALYTICS_COLORS[palette_index]


def face_distance(desc1, desc2) -> float:
    if not desc1 or not desc2 or len(desc1) != len(desc2):
        return 999.0
    return math.sqrt(sum((float(a) - float(b)) ** 2 for a, b in zip(desc1, desc2)))


def extract_face_embeddings(embedding, embeddings) -> list[list[float]]:
    raw_samples = embeddings or ([embedding] if embedding else [])
    normalized_samples = []
    sample_length = None

    for sample in raw_samples:
        if sample is None:
            continue

        normalized_sample = [float(value) for value in sample]
        if not normalized_sample:
            continue

        if sample_length is None:
            sample_length = len(normalized_sample)
        elif len(normalized_sample) != sample_length:
            raise HTTPException(
                status_code=400,
                detail="Las muestras faciales no tienen el mismo tamano.",
            )

        normalized_samples.append(normalized_sample)

    if not normalized_samples:
        raise HTTPException(status_code=400, detail="No se recibieron muestras faciales validas.")

    if sample_length is not None and sample_length < 32:
        raise HTTPException(status_code=400, detail="La muestra facial recibida es incompleta.")

    return normalized_samples


def serialize_user(user: Optional[User], db: Session) -> Optional[Dict]:
    if user is None:
        return None
    sessions_count = (
        db.query(func.count(SesionEntrenamiento.id))
        .filter(SesionEntrenamiento.user_id == user.id, SesionEntrenamiento.status == "completed")
        .scalar()
        or 0
    )
    face_samples_count = (
        db.query(func.count(UserFace.id))
        .filter(UserFace.user_id == user.id)
        .scalar()
        or 0
    )
    return {
        "id": user.id,
        "nombre": user.nombre,
        "role": user.role,
        "points_balance": user.points_balance,
        "points_earned": user.points_earned,
        "points_redeemed": user.points_redeemed,
        "face_samples_count": int(face_samples_count),
        "sessions_count": int(sessions_count),
        "created_at": user.created_at.isoformat() if user.created_at else None,
    }


def serialize_basic_user(user: User) -> Dict:
    return {
        "id": user.id,
        "nombre": user.nombre,
        "role": user.role,
        "color": build_user_chart_color(user),
    }


def sort_totals(items) -> list:
    return sorted(
        list(items),
        key=lambda item: (
            -int(item.get("total_reps", 0)),
            -int(item.get("total_points", 0)),
            item.get("nombre", ""),
        ),
    )


def serialize_exercise(exercise: Ejercicio) -> Dict:
    return {
        "id": exercise.id,
        "codigo": exercise.codigo,
        "nombre": exercise.nombre,
        "descripcion": exercise.descripcion,
        "image_path": exercise.image_path,
        "color_hex": exercise.color_hex,
        "puntos_por_rep": exercise.puntos_por_rep,
        "objetivo_reps": exercise.objetivo_reps,
        "duracion_segundos": exercise.duracion_segundos,
        "activo": exercise.activo,
        "created_at": exercise.created_at.isoformat() if exercise.created_at else None,
    }


def serialize_reward(reward: Recompensa) -> Dict:
    return {
        "id": reward.id,
        "nombre": reward.nombre,
        "descripcion": reward.descripcion,
        "costo_puntos": reward.costo_puntos,
        "stock": reward.stock,
        "activo": reward.activo,
        "created_at": reward.created_at.isoformat() if reward.created_at else None,
    }


def serialize_session(session: SesionEntrenamiento) -> Dict:
    return {
        "id": session.id,
        "user_id": session.user_id,
        "exercise_id": session.ejercicio_id,
        "exercise_name": session.ejercicio.nombre if session.ejercicio else None,
        "exercise_code": session.ejercicio.codigo if session.ejercicio else None,
        "exercise_color": session.ejercicio.color_hex if session.ejercicio else None,
        "started_at": session.started_at.isoformat() if session.started_at else None,
        "ended_at": session.ended_at.isoformat() if session.ended_at else None,
        "total_reps": session.total_reps,
        "duracion_segundos": session.duracion_segundos,
        "points_earned": session.points_earned,
        "status": session.status,
    }


def serialize_history_session(session: SesionEntrenamiento) -> Dict:
    started_local = to_local_datetime(session.started_at)
    ended_local = to_local_datetime(session.ended_at) if session.ended_at else None
    return {
        "session_id": session.id,
        "exercise_name": session.ejercicio.nombre if session.ejercicio else "Ejercicio",
        "exercise_code": session.ejercicio.codigo if session.ejercicio else "unknown",
        "exercise_color": session.ejercicio.color_hex if session.ejercicio else "#38bdf8",
        "reps": session.total_reps or 0,
        "points_earned": session.points_earned or 0,
        "duration_seconds": session.duracion_segundos or 0,
        "started_at": started_local.isoformat(),
        "ended_at": ended_local.isoformat() if ended_local else None,
        "started_label": started_local.strftime("%d/%m/%Y %H:%M"),
    }


def build_ticket(session: SesionEntrenamiento, user: User, exercise: Ejercicio) -> Dict:
    return {
        "session_id": session.id,
        "user_name": user.nombre,
        "exercise_name": exercise.nombre,
        "reps": session.total_reps,
        "points_earned": session.points_earned,
        "points_balance": user.points_balance,
        "printed_at": now_iso(),
    }


def calculate_duration(started_at) -> int:
    if started_at is None:
        return 0
    reference = started_at
    if reference.tzinfo is None:
        reference = reference.replace(tzinfo=timezone.utc)
    delta = datetime.now(timezone.utc) - reference
    return max(1, int(delta.total_seconds()))


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone(APP_TIMEZONE).isoformat()
