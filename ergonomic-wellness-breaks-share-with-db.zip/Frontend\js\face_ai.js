const MODEL_URL = new URL("../../Resources/models", import.meta.url).href;

const FACE_SAMPLE_TARGET = 4;
const FACE_SAMPLE_MINIMUM = 3;
const FACE_SAMPLE_MAX_ATTEMPTS = 12;
const FACE_SAMPLE_DELAY_MS = 220;

function getApi() {
  if (!window.WellnessAPI) {
    throw new Error("La API del sistema no esta disponible.");
  }
  return window.WellnessAPI;
}

function normalizeSessionUser(user) {
  return {
    id: user.id,
    name: user.nombre,
    role: user.role,
    points: user.points_balance || 0,
    totalPoints: user.points_earned || 0,
    faceSamples: user.face_samples_count || 0
  };
}

function saveCurrentUser(user) {
  localStorage.setItem("user", user.name);
  localStorage.setItem("role", user.role);
  localStorage.setItem("userId", String(user.id));
  localStorage.setItem("currentUser", JSON.stringify(user));
}

function wait(ms) {
  return new Promise(resolve => {
    window.setTimeout(resolve, ms);
  });
}

function averageEmbeddings(embeddings) {
  if (!embeddings.length) return [];

  const totals = new Array(embeddings[0].length).fill(0);
  embeddings.forEach(embedding => {
    embedding.forEach((value, index) => {
      totals[index] += value;
    });
  });

  return totals.map(value => value / embeddings.length);
}

async function captureFaceEmbeddings(videoElement) {
  const embeddings = [];

  for (let attempt = 0; attempt < FACE_SAMPLE_MAX_ATTEMPTS; attempt += 1) {
    const descriptor = await getFaceDescriptor(videoElement);
    if (descriptor) {
      embeddings.push(Array.from(descriptor));
      if (embeddings.length >= FACE_SAMPLE_TARGET) {
        break;
      }
    }

    if (attempt < FACE_SAMPLE_MAX_ATTEMPTS - 1) {
      await wait(FACE_SAMPLE_DELAY_MS);
    }
  }

  if (embeddings.length < FACE_SAMPLE_MINIMUM) {
    return null;
  }

  return embeddings;
}

function buildFacePayload(embeddings) {
  return {
    embedding: averageEmbeddings(embeddings),
    embeddings
  };
}

export async function cargarModelosFaciales() {
  await Promise.all([
    faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
    faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
    faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
  ]);
}

export async function getFaceDescriptor(video) {
  const detection = await faceapi
    .detectSingleFace(video)
    .withFaceLandmarks()
    .withFaceDescriptor();

  if (!detection) return null;
  return detection.descriptor;
}

export function faceDistance(desc1, desc2) {
  let sum = 0;
  for (let i = 0; i < desc1.length; i += 1) {
    sum += (desc1[i] - desc2[i]) ** 2;
  }
  return Math.sqrt(sum);
}

export async function registrarUsuario(videoElement, nombreUsuario, role = "user") {
  const embeddings = await captureFaceEmbeddings(videoElement);
  if (!embeddings) {
    return {
      exito: false,
      mensaje: "No se pudieron capturar suficientes muestras del rostro. Mantente de frente y con buena luz."
    };
  }

  try {
    const api = getApi();
    const response = await api.registerFace({
      nombre: nombreUsuario,
      role,
      ...buildFacePayload(embeddings)
    });
    const usuario = normalizeSessionUser(response.user);
    saveCurrentUser(usuario);

    return {
      exito: true,
      mensaje: response.message,
      usuario
    };
  } catch (error) {
    return {
      exito: false,
      mensaje: error.message || "No se pudo registrar el usuario."
    };
  }
}

export async function loginUsuario(videoElement) {
  const embeddings = await captureFaceEmbeddings(videoElement);
  if (!embeddings) {
    return {
      validado: false,
      mensaje: "No se detectaron suficientes capturas del rostro. Mantente de frente a la camara."
    };
  }

  try {
    const api = getApi();
    const response = await api.loginFace(buildFacePayload(embeddings));

    if (!response.validado || !response.user) {
      return {
        validado: false,
        mensaje: response.message || "Usuario no reconocido."
      };
    }

    const usuario = normalizeSessionUser(response.user);
    saveCurrentUser(usuario);

    return {
      validado: true,
      usuario,
      mensaje: response.message
    };
  } catch (error) {
    return {
      validado: false,
      mensaje: error.message || "No se pudo validar el usuario."
    };
  }
}

export async function verificarIdentidad(videoElement, nombreUsuario) {
  const resultado = await loginUsuario(videoElement);
  if (!resultado.validado) {
    return resultado;
  }

  if (resultado.usuario.name.toLowerCase() !== nombreUsuario.trim().toLowerCase()) {
    return {
      validado: false,
      mensaje: "El rostro detectado no coincide con el nombre solicitado."
    };
  }

  return {
    validado: true,
    mensaje: `Acceso permitido para ${resultado.usuario.name}.`,
    usuario: resultado.usuario
  };
}
